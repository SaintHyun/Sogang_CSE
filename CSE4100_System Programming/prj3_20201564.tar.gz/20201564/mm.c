/*
 * Simple, 32-bit and 64-bit clean allocator based on implicit free
 * lists, first-fit placement, and boundary tag coalescing, as described
 * in the CS:APP3e text. Blocks must be aligned to doubleword (8 byte)
 * boundaries. Minimum block size is 16 bytes.
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "mm.h"
#include "memlib.h"

/*********************************************************
 * NOTE TO STUDENTS: Before you do anything else, please
 * provide your team information in the following struct.
 ********************************************************/
team_t team = {
    "20201564",
    "Kim Seong Hyun",
    "kiles1201@naver.com",
};

/* Basic constants and macros */
#define WSIZE 4             /* Word and header/footer size (bytes) */
#define DSIZE 8             /* Double word size (bytes) */
#define CHUNKSIZE (1 << 12) /* Extend heap by this amount (bytes) */
#define MINIMUM 24

#define MAX(x, y) ((x) > (y) ? (x) : (y))

/* Pack a size and allocated bit into a word */
#define PACK(size, alloc) ((size) | (alloc))

/* Read and write a word at address p */
#define GET(p) (*(unsigned int *)(p))
#define PUT(p, val) (*(unsigned int *)(p) = (val))

/* Read the size and allocated fields from address p */
#define GET_SIZE(p) (GET(p) & ~0x7)
#define GET_ALLOC(p) (GET(p) & 0x1)

/* Given block ptr bp, compute address of its header and footer */
#define HDRP(bp) ((char *)(bp)-WSIZE)
#define FTRP(bp) ((char *)(bp) + GET_SIZE(HDRP(bp)) - DSIZE)

/* Given block ptr bp, compute address of next and previous blocks */
#define NEXT_BLKP(bp) ((char *)(bp) + GET_SIZE(((char *)(bp)-WSIZE)))
#define PREV_BLKP(bp) ((char *)(bp)-GET_SIZE(((char *)(bp)-DSIZE)))

/* Global variables */
static char *heap_listp = 0; /* Pointer to first block */
static char *next_listp = 0; /* Pointer to next fit blcok */

/* Function prototypes for internal helper routines */
static void *extend_heap(size_t words);
static void place(void *bp, size_t asize);
static void *find_fit(size_t asize);
static void *coalesce(void *bp);

int mm_init(void)
{
    /* 빈 heap 초기화 */
    if ((heap_listp = mem_sbrk(4 * WSIZE)) == NULL)
        return -1;
    PUT(heap_listp, 0);                            /* Alignment padding */
    PUT(heap_listp + (1 * WSIZE), PACK(DSIZE, 1)); /* Prologue header */
    PUT(heap_listp + (2 * WSIZE), PACK(DSIZE, 1)); /* Prologue footer */
    PUT(heap_listp + (3 * WSIZE), PACK(0, 1));     /* Epilogue header */
    heap_listp += (2 * WSIZE);
    next_listp = heap_listp; //next_fit

    /* CHUNKSIZE byte만큼 heap 크기 증가 */
    if (extend_heap(CHUNKSIZE / WSIZE) == NULL)
        return -1;
    return 0;
}

void *mm_malloc(size_t size)
{
    size_t asize;
    size_t extendsize;
    char *bp;

    if (heap_listp == 0)
        mm_init();

    /* 의미 없는 요청 무시 */
    if (size <= 0)
        return NULL;

    /* alignment보다 작은 크기일 경우 minimum 크기인 16바이트로 설정해준다. 그 외에도 align에 맞춰서 크기를 정해준다. */
    if (size <= DSIZE)
        asize = 2 * DSIZE;
    else
        asize = DSIZE * ((size + (DSIZE) + (DSIZE - 1)) / DSIZE);

    /* next fit으로 bp를 찾아서 bp에 asize만큼 할당 */
    if ((bp = find_fit(asize)))
    {
        place(bp, asize);
        return bp;
    }

    /* 찾은 fit이 없다면 일정 크기만큼 힙 확장, 불가능할 경우 malloc 실패, NULL 리턴 */
    extendsize = MAX(asize, CHUNKSIZE);
    if ((bp = extend_heap(extendsize / WSIZE)) == NULL)
        return NULL;
    place(bp, asize); // 확장한 곳에 bp 위치
    return bp;
}

void mm_free(void *bp)
{
    if (bp == NULL)
        return;

    size_t size = GET_SIZE(HDRP(bp)); // free할 size

    PUT(HDRP(bp), PACK(size, 0)); // header와 footer를 각각 할당 해제
    PUT(FTRP(bp), PACK(size, 0));
    coalesce(bp); // coalesing
}

static void *coalesce(void *bp)
{
    size_t prev_alloc = GET_ALLOC(FTRP(PREV_BLKP(bp))); // 이전 블록이 allocate 되어 있는가?
    size_t next_alloc = GET_ALLOC(HDRP(NEXT_BLKP(bp))); // 다음 블록이 allocate 되어 있는가?
    size_t size = GET_SIZE(HDRP(bp));

    if (prev_alloc && next_alloc) // 둘 다 allocate 된 경우
        return bp;

    else if (prev_alloc && !next_alloc)        // 다음 블록만 free인 경우
    {                                         
        size += GET_SIZE(HDRP(NEXT_BLKP(bp))); // 다음 블록의 size를 더해서 새 size
        PUT(HDRP(bp), PACK(size, 0));          // header footer 설정
        PUT(FTRP(bp), PACK(size, 0));
    }

    else if (!prev_alloc && next_alloc)          // 이전 블록만 free인 경우
    {                                            
        size += GET_SIZE(HDRP(PREV_BLKP(bp)));   // 이전 블록의 size를 더해서 새 size
        PUT(FTRP(bp), PACK(size, 0));            // footer 설정
        PUT(HDRP(PREV_BLKP(bp)), PACK(size, 0)); // 이전 블록 헤더를 새로운 헤더로
        bp = PREV_BLKP(bp);
    }

    else                                                                       // 둘 다 free인 경우
    {                                                                         
        size += GET_SIZE(HDRP(PREV_BLKP(bp))) + GET_SIZE(FTRP(NEXT_BLKP(bp))); // 이전 블록과 다음 블록의 size를 더해서 새 size
        PUT(HDRP(PREV_BLKP(bp)), PACK(size, 0));                               // 이전 블록의 헤더를 새로운 헤더로
        PUT(FTRP(NEXT_BLKP(bp)), PACK(size, 0));                               // 다음 블록의 푸터를 새로운 푸터로
        bp = PREV_BLKP(bp);
    }

    if ((next_listp > (char *)bp) && (next_listp < NEXT_BLKP(bp)))
        next_listp = bp;
    return bp;
}

void *mm_realloc(void *bp, size_t size)
{
    size_t old_size = GET_SIZE(HDRP(bp));
    size_t new_size = size + (2 * WSIZE);

    // 새로운 size가 기존 size보다 크지 않으면 굳이 다시 malloc할 이유가 없다.
    if (new_size <= old_size)
        return bp;
    else
    {
        // size_t prev_alloc = GET_ALLOC(FTRP(PREV_BLKP(bp))); 구현 실패
        size_t next_alloc = GET_ALLOC(HDRP(NEXT_BLKP(bp)));
        // size_t prev_size = GET_SIZE(HDRP(PREV_BLKP(bp))); 구현 실패
        size_t next_size = GET_SIZE(FTRP(NEXT_BLKP(bp)));

        // next block이 가용상태이고 old, next block의 사이즈 합이 new_size보다 크면 그냥 그거 바로 합쳐서 쓰기
        if (!next_alloc && old_size + next_size >= new_size)
        {
            PUT(HDRP(bp), PACK(old_size + next_size, 1));
            PUT(FTRP(bp), PACK(old_size + next_size, 1));
            place(bp, old_size + next_size);
            return bp;
        }
        // prev block이 가용상태이고 old, prev block의 사이즈 합이 new_size보다 크면 그냥 그거 바로 합쳐서 쓰기 - 구현 실패
        /*else if(!prev_alloc && old_size + prev_size >= new_size && prev_size > old_size)
        {
            memcpy(HDRP(PREV_BLKP(bp)) + WSIZE, bp, old_size);
            PUT(HDRP(PREV_BLKP(bp)), PACK(old_size + prev_size, 1));
            PUT(HDRP(bp), 0);
            PUT(FTRP(bp), PACK(old_size + prev_size, 1));
            bp = PREV_BLKP(bp);
            return bp;
        }*/
        // 아니면 새로 block 만들어서 거기로 옮기기
        else
        {
            void *new_bp = mm_malloc(new_size);
            memcpy(new_bp, bp, new_size); 
            mm_free(bp);
            return new_bp;
        }
    }
}

static void *extend_heap(size_t words)
{
    char *bp;
    size_t size;

    /* 요청한 크기를 Double word size의 배수로 반올림해주어 추가 heap 공간 요청, 실패시 NULL 리턴 */
    size = (words % 2) ? (words + 1) * WSIZE : words * WSIZE;
    if ((long)(bp = mem_sbrk(size)) == -1)
        return NULL;

    /* 추가한 heap의 공간의 header, footer, epilogue header 설정 */
    PUT(HDRP(bp), PACK(size, 0));         /* Free block header */
    PUT(FTRP(bp), PACK(size, 0));         /* Free block footer */
    PUT(HDRP(NEXT_BLKP(bp)), PACK(0, 1)); /* New epilogue header */

    /* 가능하면 coalescing */
    return coalesce(bp);
}

static void place(void *bp, size_t asize)
{
    size_t csize = GET_SIZE(HDRP(bp));
    // place 후 나머지 블록의 크기가 Double size word의 두 배, 즉 최소 할당 크기보다 크다면 블록은 분할해야 한다.
    if ((csize - asize) >= (2 * DSIZE))
    {
        PUT(HDRP(bp), PACK(asize, 1));
        PUT(FTRP(bp), PACK(asize, 1));
        bp = NEXT_BLKP(bp);
        PUT(HDRP(bp), PACK(csize - asize, 0));
        PUT(FTRP(bp), PACK(csize - asize, 0));
    }
    else // 나머지는 그냥 할당
    {
        PUT(HDRP(bp), PACK(csize, 1));
        PUT(FTRP(bp), PACK(csize, 1));
    }
}

static void *find_fit(size_t asize)
{
    /* next_fit search를 한다. */
    char *prev_listp = next_listp;

    /* 이전 next fit으로 search한 곳부터 search 시작*/
    for (next_listp = next_listp; GET_SIZE(HDRP(next_listp)) > 0; next_listp = NEXT_BLKP(next_listp))
    {
        if (!GET_ALLOC(HDRP(next_listp)) && asize <= GET_SIZE(HDRP(next_listp)))
            return next_listp;
    }
    /* 없으면 처음부터 다시 시작... */
    for (next_listp = heap_listp; next_listp < prev_listp; next_listp = NEXT_BLKP(next_listp))
    {
        if (!GET_ALLOC(HDRP(next_listp)) && asize <= GET_SIZE(HDRP(next_listp)))
            return next_listp;
    }
    return NULL; /* 없으면 NULL 리턴 ㅜㅠㅠㅜ */
}
