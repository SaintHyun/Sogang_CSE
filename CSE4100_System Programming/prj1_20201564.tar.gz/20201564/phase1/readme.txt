history 로그는 history.log 파일에 저장됩니다. 즉, 별도로 건들 필요는 없습니다.
사용방법
make
./myshell