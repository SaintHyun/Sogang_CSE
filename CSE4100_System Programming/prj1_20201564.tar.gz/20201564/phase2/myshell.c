/* $begin shellmain */
#include "myshell.h"
#include <errno.h>
#define MAXARGS 128

int hisoptionflag=0;

/* Function prototypes */
void eval(char *cmdline);
int parseline(char *buf, char **argv);
int builtin_command(char **argv); 
char curdir[MAXLINE]={0,};

typedef struct node{ //history 스택
    char cmd[MAXLINE];
    struct node *next;
}node;

typedef struct{
    node *top;
}stack;


void init(stack *hislog)
{
    hislog->top=NULL;
}

void push(stack *hislog, char *aaa)
{
    //printf("push %s\n",aaa);
    node *temp=(node*)malloc(sizeof(node));
    strcpy(temp->cmd,aaa);
    temp->next=hislog->top;
    hislog->top=temp;
    //printf("push logtop %s\n",hislog->top->cmd);
}

void printlog()
{
    FILE *fp1=fopen(curdir,"r");
    int i=0;
    char sss[MAXLINE];
    if(fp1!=NULL)
    {
        while(!feof(fp1))
        {
            char cmdlog[MAXLINE];
            fgets(cmdlog,MAXLINE,fp1);  
            printf("%6d %s",++i,cmdlog);
            if(feof(fp1)) break;
            memset(cmdlog,0,MAXLINE);
        }
    }   
    printf("\n");
    //if(!strcmp(sss,"history")) printf("%5d %s",++i,"history");
    fclose(fp1);
}

stack hislog; //history log

int compare(stack *hislog, char *a)
{
    int len=strlen(hislog->top->cmd);
    return strcmp(hislog->top->cmd, a);
}

void exceptcontrol(stack *hislog) //처음 실행될 때 stack에 넣어주는데, \n 예외 처리
{
    int len=strlen(hislog->top->cmd);
    if(hislog->top->cmd[len-1]!='\n')
    {
        hislog->top->cmd[len]='\n';
        hislog->top->cmd[len+1]=0;
        //fprintf(fp2,"\n");
    }
    //printf("%s",hislog->top->cmd);
}

void replace_str1(int *idx, char *a, stack *hislog)
{
    int i;
    char temp[MAXLINE]={0,};
    if(*idx!=0)
    {
        strncpy(temp, a, *idx);
        strcat(temp,hislog->top->cmd);
        if(temp[strlen(temp)-1]=='\n') temp[strlen(temp)-1]=0;
        strcat(temp,a+*idx+2);
        strcpy(a, temp);
    }
    else
    {
        strcpy(temp,hislog->top->cmd);
        if(temp[strlen(temp)-1]=='\n') temp[strlen(temp)-1]=0;
        strcat(temp,a+2);
        strcpy(a, temp);
    }
    
    *idx=*idx+strlen(hislog->top->cmd)-1;
    memset(temp,0,MAXLINE);
}

void replace_str2(int *idx, char *a, stack *hislog, int jj, int num) //!# 전용 replace
{
    int i;
    char temp[MAXLINE];
    char aa[MAXLINE];
    FILE *fp1=fopen(curdir,"r");
    for(i=1; i<num; i++)
    {  
        fgets(aa,MAXLINE,fp1);
        memset(aa,0,MAXLINE);
    }
    if(feof(fp1))
    {
        printf("-bash: !%d: event not found\n",num);
        hisoptionflag=1;
        memset(aa,0,MAXLINE);
        return;
    }
    fgets(aa,MAXLINE,fp1);

    if(*idx!=0)
    {
        strncpy(temp, a, *idx);
        strcat(temp,aa);
        if(temp[strlen(temp)-1]=='\n') temp[strlen(temp)-1]=0;
        strcat(temp,a+*idx+jj+1);
        strcpy(a, temp);
    }
    else
    {
        strcat(temp,aa);
        if(temp[strlen(temp)-1]=='\n') temp[strlen(temp)-1]=0;
        strcat(temp,a+jj+1);
        strcpy(a, temp);
    }
    
    *idx=*idx+strlen(aa)-1;
    memset(temp,0,MAXLINE);
    fclose(fp1);
}

int pipecheck(char *buf)
{
    char quote=0;
    int i;
    for(i=0; buf[i]!=0; i++)
    {
        if(buf[i]=='\'' || buf[i]=='\"') //따옴표를 만나면 그 안에 있는 pipe는 모두 무시된다.
        {
            if(quote==buf[i]) quote=0; //다시 따옴표를 만나면 NULL로
            else quote=buf[i]; //따옴표가 아니면 그 문자로 변경
        }
        else if(buf[i]=='|') //pipe를 만나면
        {
            if(quote==0) return 1; //그게 따옴표 안에 있는게 아니면 | 기능을 수행하는 것. 따라서 return 1
        }
    }
    return 0; //끝까지 못 찾았으면 pipe가 없음.
}
int builtin_flag=0;

void pipeline(char* cmdline)
{
    int fd[2];
    pid_t pid;
    int pipeline = 0; 
    char *argv[MAXARGS]; 
    char buf[MAXLINE];
    char* current;
    char* next;
    char temp[MAXLINE] = {0,};
    int bg;
    
    strcpy(buf, cmdline);
    current = strtok(buf, "|"); // 처음 파이프라인을 만나기 전까지 복사
    next = strtok(NULL, ""); // 다음 명령어

    while(current != NULL) //모든 파이프가 실행될 때 까지
    {
        builtin_flag=0;
        strcpy(temp, current); //임시 복사
        // 파이프라인 사이에 공백이 없을 경우 공백을 추가해줄 것
        int len=strlen(current);
        if(temp[len-1]!='\n' && temp[len-1]!=' ')
        {
            temp[len]=' ';
            temp[len+1]=0;
        }
        bg = parseline(temp, argv); //파이프라인 앞의 명령어를 parse하여 명령어와 옵션으로 구분
        if (argv[0] == NULL) return; /* Ignore empty lines */
        pipe(fd);  //pipe 생성
        //printf("before fork pipe1: %d %d %d\n",pipeline, fd[0],fd[1]);
        pid = fork();
        if(pid==0) //pid가 0이므로 child process 
        {
            //printf("child pipe1: %d %d %d\n",pipeline, fd[0],fd[1]);
            dup2(pipeline, 0); //  STDIN이 pipeline, 즉 앞 프로세스의 출력으로 변경
            //printf("child pipe2: %d %d %d\n",pipeline, fd[0], fd[1]);
            if (next != NULL) dup2(fd[1], 1); //만약 다음 명령어가 있으면 출력을 fd[1]으로 변경
            //만약 없으면 그대로 stdout
            close(fd[0]); //기존 input은 필요 없음
            if(!builtin_command(argv))
            {
                if (execvpe(argv[0], argv, environ) < 0) //phase1과 동일
                {
                    printf("%s: Command not found.\n", argv[0]);
                    exit(0);
                    
                }
            }
            else builtin_flag=0;
            
        }
        if (!bg)
        { 
            int status;
            if (waitpid(pid, &status, 0) < 0) //child process가 먼저 실행될 수 있도록 한다.
            {
                //unix_error("waitpid error");
                if(builtin_flag) unix_error("waitpid error");
                else exit(0);
            } 
        }
        // 이상 phase1과 동일
        close(fd[1]); //기존 output은 필요 없음
        pipeline = fd[0]; //다음 child process의 input fd를 저장해준다.
        //printf("parent pipe: %d %d %d\n",pipeline, fd[0],fd[1]);
        if(next == NULL) return;
        if(pipecheck(next)) // 다음에도 pipeline이 있을 경우
        {
            current = strtok(next, "|"); // while문 시작하기 전에 했던 대로 strtok하여 | 기준으로 나눠준다.
            next = strtok(NULL, ""); // 
        }
        else // 다음에 pipeline이 없을 경우
        {
            current = next; // 다음 명령어가 마지막 명령어 이므로
            next = NULL; //next는 NULL
        }
        
    }
}

int main() 
{
    char cmdline[MAXLINE]; /* Command line */
    char copied[MAXLINE];
    int markflag=0;
    hisoptionflag=0;
    FILE *fp1=fopen("history.log","r");
    strcpy(curdir,getenv("PWD"));
    strcat(curdir,"/history.log");
    
    //hislog=(stack*)malloc(sizeof(stack));
    init(&hislog);
    if(fp1!=NULL) //shell 실행할 때 history를 스택에 저장
    {
        while(!feof(fp1))
        {
            char cmdlog[MAXLINE];
            fgets(cmdlog,MAXLINE,fp1);  
            push(&hislog,cmdlog);
            memset(cmdlog,0,MAXLINE);
        }
        exceptcontrol(&hislog); //기존 history의 맨 마지막 log 문자열의 맨 끝에 \n을 넣어주는 함수.
    }   
    fclose(fp1);
    
    while(1) 
    {  
        hisoptionflag=0; //!#에서 #이 history log 파일보다 많은 경우에 대한 flag
        markflag=0; //!! 혹은 !#이 있을 경우의 flag
        /* Read */
        printf("CSE4100-MP-P1> ");                   
        fgets(cmdline, MAXLINE, stdin); 
        if (feof(stdin)) exit(0);

        int hisflag=0, i = 0, len=strlen(cmdline);
        //printf("first %s",cmdline);
        while(cmdline[i]!=0)
        {
            if(cmdline[i]=='!')
            {
                if(cmdline[i+1]=='!') //!!이면 hislog stack의 top 문자열로 대체한다.
                {
                    replace_str1(&i, cmdline, &hislog);
                    markflag=1;
                    continue;
                }
                int j=0;
                char numchar[MAXLINE];
                while(cmdline[i+j+1]>='0' && cmdline[i+j+1]<='9') //!#에 대한 처리 과정
                {
                    numchar[j]=cmdline[i+j+1];
                    j++;
                }
                if(j>0)
                {
                    int num=atoi(numchar);
                    replace_str2(&i,cmdline,&hislog,j, num);
                    if(hisoptionflag) memset(cmdline,0,MAXLINE);
                    memset(numchar,0,MAXLINE);
                    markflag=1;
                    continue;
                }
            }
            i++;
        }
        if(hisoptionflag)
        {
            memset(cmdline,0,MAXLINE);
            continue;
        }
        if(markflag)
        {
            printf("%s",cmdline);
        }
        //printf("%s",cmdline);
        strcpy(copied,cmdline);
        if(copied[0]!='\n' && compare(&hislog,copied)) // 공백 명령어 무시
        {
            FILE *fp2=fopen(curdir,"a+");
            push(&hislog,copied);
            int len=strlen(copied);
            copied[len-1]=0;
            fprintf(fp2,"\n%s",copied);
            fclose(fp2);
        }
        //printf("%s",cmdline);
        /* Evaluate */
        eval(cmdline);
        memset(cmdline,0,MAXLINE);
    } 
    // fclose(fp2);
}
/* $end shellmain */
  
/* $begin eval */
/* eval - Evaluate a command line */
void eval(char *cmdline) 
{
    char *argv[MAXARGS]; /* Argument list execve() */
    char buf[MAXLINE];   /* Holds modified command line */
    int bg;              /* Should the job run in bg or fg? */
    pid_t pid;           /* Process id */
    int status;
    if(pipecheck(cmdline) == 1) pipeline(cmdline); //pipeline이 존재하면 pipe로 따로 처리해준다
    else
    {
        strcpy(buf, cmdline);
        bg = parseline(buf, argv); 
        if (argv[0] == NULL) return;   /* Ignore empty lines */
        //printf("%s 1 %s\n",cmdline,argv[0]);
        if (!builtin_command(argv)) //not builtin command
        { //quit -> exit(0), & -> ignore, other -> run
            pid = fork();
            if(pid == 0) //child process일 때만
            {
                if (execvpe(argv[0], argv, environ) < 0) //0보다 작으면 이상한 명령어일 경우, 아니면 builtin command가 아닌 명령어 실행
                {	
                    printf("%s: Command not found.\n", argv[0]);
                    exit(1);
                }
            }

            /* Parent waits for foreground job to terminate */
            if (!bg)
            { 
                int status;
                if (waitpid(pid, &status, 0) < 0)
                {
                    unix_error("waitpid error");
                } 
            }
            else printf("%d %s", pid, cmdline);
        }
    }
    return;
}

/* If first arg is a builtin command, run it and return true */
int builtin_command(char **argv) 
{
    builtin_flag=1;
    if (!strcmp(argv[0], "exit")) /* exit(quit) command */
	    exit(0);  
    if (!strcmp(argv[0], "&"))    /* Ignore singleton & */
	    return 1;
    if(!strcmp(argv[0],"cd"))
    {
        char destination[MAXLINE];
        if(argv[1]==NULL) strcpy(destination,getenv("HOME")); //cd 후에 인자가 없으면 HOME 디렉토리로 이동한다.
        else strcpy(destination,argv[1]);
        if(chdir(destination)==-1) printf("cd %s: No such file or directory\n",argv[1]);
        return 1;
    }
    if(!strcmp(argv[0],"history"))
    {
        //printf("printlog\n");
        printlog();
        return 1;
    }
    return 0;                     /* Not a builtin command */
}
/* $end eval */

/* $begin parseline */
/* parseline - Parse the command line and build the argv array */
int parseline(char *buf, char **argv) 
{
    char *delim;         /* Points to first space delimiter */
    int argc;            /* Number of args */
    int bg;              /* Background job? */
    char quote; //따옴표를 처리하기 위함

    if(buf[strlen(buf)-1]=='\n') buf[strlen(buf)-1] = ' ';  /* Replace trailing '\n' with space */
    while (*buf && (*buf == ' ')) /* Ignore leading spaces */
	    buf++;

    /* Build the argv list */
    argc = 0;
    while ((delim = strchr(buf, ' '))) //공백을 기준으로 buf 생성
    {
        argv[argc++] = buf;
        *delim = 0;
        buf = delim + 1;
        while (*buf && (*buf == ' ')) /* Ignore spaces */
            buf++;
        //printf("%s\n",buf);
        if(*buf=='\"' || *buf=='\'') //따옴표가 있을 경우
        {
            quote = *buf;
            *buf = 0;//따옴표 이전 문자를 따로 뺀다.
            buf++; // 다음 문자열 parsing을 위해 buf 주소 1 증가.
            delim = strchr(buf, quote); //따옴표를 기준으로 분할
            //printf("delim %s buf %s\n",delim,buf);
            if (delim != NULL)
            {
                *delim = 0; //일단 현재 문자 NULL로 해주고
                argv[argc++] = buf; //argv에 따옴표 이전 문자열을 복사한 다음
                buf = delim + 1;  //따옴표 이후 문자열의 첫 주소를 buf가 가리키게 변경한다.
                
            } 
        }
        while (*buf && (*buf == ' ')) /* Ignore spaces */
            buf++;
    }
    argv[argc] = NULL;
    
    if (argc == 0)  /* Ignore blank line */ return 1;

    /* Should the job run in the background? */
    if ((bg = (*argv[argc-1] == '&')) != 0) argv[--argc] = NULL;
    return bg;
    
}
/* $end parseline */


