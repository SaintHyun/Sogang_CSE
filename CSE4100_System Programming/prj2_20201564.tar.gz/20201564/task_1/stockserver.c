#include "csapp.h"

//lecture note code: struct pool
typedef struct pool
{
    int maxfd;
    fd_set read_set;
    fd_set ready_set;
    int nready;
    int maxi;
    int clientfd[FD_SETSIZE];
    rio_t clientrio[FD_SETSIZE];
}pool;

//project descriptor code: struct item
typedef struct item
{
    int ID;
    int left_stock;
    int price;
    struct item* left_child;
    struct item* right_child;
}item;

item* init_pool(item* root, int listenfd, pool *p);
void add_client(int, pool*);
void check_clients(item* root, pool*);
item* create(int ID, int left_stock, int price);
item* insert(item* cur, int ID, int left_stock, int price);
int update(item*,int,int);
void show(item* root, char*);
void inorder_print_file(FILE* fp, item* root);
void item_free(item* root);


int byte_cnt=0;
int client_cnt=0;

int main(int argc, char **argv) 
{
    int listenfd, connfd;
    socklen_t clientlen;
    struct sockaddr_storage clientaddr;  /* Enough space for any address */ 
    static pool pool;
    item* root=NULL;

    if (argc != 2) {
        fprintf(stderr, "usage: %s <port>\n", argv[0]);
        exit(0);
    }
	listenfd=Open_listenfd(argv[1]);
	root=init_pool(root,listenfd,&pool);
    while (1) {
        pool.ready_set=pool.read_set;
        pool.nready=Select(pool.maxfd+1,&pool.ready_set,NULL,NULL,NULL);
        if(FD_ISSET(listenfd,&pool.ready_set))
        {
            clientlen=sizeof(struct sockaddr_storage);
            connfd=Accept(listenfd, (SA *)&clientaddr, &clientlen);
            add_client(connfd,&pool);
        }
        check_clients(root, &pool);
    }
    item_free(root);
    exit(0);
}

item* init_pool(item* root, int listenfd, pool *p)
{
    FILE* fp=Fopen("stock.txt","r");
    int ID, left_stock,price;
    while(fscanf(fp,"%d%d%d",&ID,&left_stock,&price)!=EOF)
    {
        //printf("inserting\n");
        root=insert(root,ID,left_stock,price);
        //printf("root==NULL? %d\n",root==NULL);
       // inorder_print_file(STDIN_FILENO,root);
    }
    Fclose(fp);

    // lecture note code: init_pool
    int i;
    p->maxi=-1;
    for(i=0; i<FD_SETSIZE; i++)
    {
        p->clientfd[i]=-1;
    }
    p->maxfd=listenfd;
    FD_ZERO(&p->read_set);
    FD_SET(listenfd, &p->read_set);
    return root;
}

void add_client(int connfd, pool *p)
{
    int i;
    p->nready--;
    for(i=0; i<FD_SETSIZE; i++)
    {
        if(p->clientfd[i]<0)
        {
            client_cnt++;
            p->clientfd[i]=connfd;
            Rio_readinitb(&p->clientrio[i], connfd);
            FD_SET(connfd,&p->read_set);
            if(connfd>p->maxfd) p->maxfd=connfd;
            if(i>p->maxi) p->maxi=i;
            break;
        }

    }
    //printf("clientcnt: %d\n",client_cnt);
    if(i==FD_SETSIZE) app_error("add_client error: Too many clients");
}

void check_clients(item* root, pool *p)
{
    int i, connfd, n;
    char buf[MAXLINE],command[MAXLINE];
    int ID, amount;
    int flag=0;
    rio_t rio;
    for(i=0; (i<=p->maxi) && (p->nready>0); i++)
    {
        connfd=p->clientfd[i];
        rio=p->clientrio[i];
        if((connfd>0) && (FD_ISSET(connfd, &p->ready_set)))
        {
            p->nready--;
            if((n=Rio_readlineb(&rio,buf,MAXLINE))!=0)
            {
                byte_cnt+=n;
                printf("Server received %d (%d total) bytes on fd %d\n",n,byte_cnt,connfd);
                sscanf(buf,"%s",command);
                //printf("%s",buf);
                if(!strcmp(command,"show"))
                {
                    //printf("show\n");
                    show(root,buf);
                }
                else
                {
                    sscanf(buf,"%s%d%d",command,&ID,&amount);
                    //printf("ID:%d amount: %d\n",ID,amount);
                    if(!strcmp(command,"sell"))
                    {
                        //printf("sell\n");
                        flag=update(root, ID,amount);
                        if(flag) sprintf(buf,"[sell] success\n");
                        else sprintf(buf,"Not enough left stock\n");
                    }
                    else if(!strcmp(command,"buy"))
                    {
                        //printf("buy\n");
                        flag=update(root, ID,(-1)*amount);
                        if(flag) sprintf(buf,"[buy] success\n");
                        else sprintf(buf,"Not enough left stock\n");
                    }
                }
                Rio_writen(connfd,buf,sizeof(buf));
                memset(buf,0,sizeof(buf));
            }
            else
            {
                Close(connfd);
                client_cnt--;
                if(!client_cnt)
                {
                    FILE* fp=Fopen("stock.txt","w");
                    inorder_print_file(fp,root);
                    Fclose(fp);
                }
                FD_CLR(connfd,&p->read_set);
                p->clientfd[i]=-1;
            }
        }
    }
}

item* create(int ID, int left_stock, int price)
{
    item* temp=(item*)malloc(sizeof(item));
    temp->ID=ID;
    temp->left_stock=left_stock;
    temp->price=price;
    temp->left_child=NULL;
    temp->right_child=NULL;
    return temp;
}

item* insert(item* cur, int ID, int left_stock, int price)
{
    if(cur==NULL) cur=create(ID,left_stock,price);
    else if(ID<cur->ID) cur->left_child=insert(cur->left_child,ID,left_stock,price);
    else cur->right_child=insert(cur->right_child,ID,left_stock,price);
    //printf("%d %d %d %d\n",(cur==NULL),cur->ID,cur->left_stock,cur->price);
    //printf("inserting\n");
    return cur;
}

int update(item* root, int ID, int amount)
{
    if(root==NULL) return 0;
    if(root->ID==ID)
    {
        if(root->left_stock + amount >= 0)
        {
            root->left_stock+=amount;
            return 1;
        }
        else return 0;
    }
    else if(root->ID<ID) return update(root->right_child,ID,amount);
    else return update(root->left_child, ID, amount);
}

void show(item* root,char* buf)
{
    if(root==NULL) return; 
    char temp[MAXLINE];
    
    show(root->left_child,buf);
    sprintf(temp, "%d %d %d\n",root->ID,root->left_stock,root->price);
    strcat(buf,temp);
    show(root->right_child,buf);
    
}

void inorder_print_file(FILE* fp, item* root)
{
    if(root==NULL) return;
    inorder_print_file(fp,root->left_child);
    fprintf(fp,"%d %d %d\n",root->ID, root->left_stock, root->price);
    inorder_print_file(fp,root->right_child);
}

void item_free(item* root)
{
    if(root==NULL) return;
    item_free(root->left_child);
    item_free(root->right_child);
    free(root);
}

/* $end echoserverimain */
