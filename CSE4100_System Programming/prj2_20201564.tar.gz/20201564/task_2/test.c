#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <setjmp.h>
#include <signal.h>
#include <dirent.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <errno.h>
#include <math.h>
#include <pthread.h>
#include <semaphore.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/inet.h>

int main(int argc, char **argv)
{
    FILE* fp=fopen("test.txt","a");
    pid_t pid;
    int status;
    int num=atoi(argv[1]);
    fprintf(fp,"READERS: CLIENT NUM: %d\n",num);
    fclose(fp);
    char *arg[5000]={"/home/anyid/proj2/task2/multiclient","localhost","60069","100",0};
    
    printf("%s %s %s %s\n",arg[0],arg[1],arg[2],arg[3]);
    //execvp(arg[0],arg);
    for(int i=1; i<=500; i++)
    {
        pid=fork();
        if(pid==0) {execvp(arg[0],arg); perror("execvp");}
        else waitpid(pid, &status, 0);
    }
}