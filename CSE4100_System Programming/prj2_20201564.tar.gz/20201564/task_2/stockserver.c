#include "csapp.h"

#define THREAD_MAX 1024
#define SBUF_SIZE 1024

//lecture note code: sbuf_t
typedef struct sbuf_t
{
    int *buf;
    int n;
    int front;
    int rear;
    sem_t mutex;
    sem_t slots; //producer lock
    sem_t items; //consumer lock
}sbuf_t;

//project descriptor code: struct item
typedef struct item
{
    int ID;
    int left_stock;
    int price;
    int readcnt;
    struct item* left_child;
    struct item* right_child;
    sem_t mutex; //for mutex lock
    sem_t w; //for readers_writers lock (first problem)
}item;


sbuf_t sbuf;
item* root=NULL;
static int byte_cnt;
int client_cnt=0, read_cnt=0;
sem_t mutex,client_mutex;

void check_threads(item* root, int); //task1에서의 check_client와 유사
item* create(int ID, int left_stock, int price); 
item* insert(item* cur, int ID, int left_stock, int price);
int update(item*,int,int,int,char*);
void show(item* root, char*);
void inorder_print_file(FILE* fp, item* root);
void item_free(item* root);


//lecture note code: sbuf related function
void sbuf_init(sbuf_t *sp, int n)
{
    sp->buf=Calloc(n,sizeof(int));
    sp->n=n;
    sp->front=sp->rear=0;
    Sem_init(&sp->mutex,0,1);
    Sem_init(&sp->slots,0,n);
    Sem_init(&sp->items,0,0);
}

void sbuf_deinit(sbuf_t *sp)
{
    Free(sp->buf);
}

void sbuf_insert(sbuf_t *sp, int item)
{
    P(&sp->slots);
    P(&sp->mutex);
    sp->buf[(++sp->rear)%(sp->n)]=item;
    V(&sp->mutex);
    V(&sp->items);
}

int sbuf_remove(sbuf_t *sp)
{
    int item;
    P(&sp->items);
    P(&sp->mutex);
    item=sp->buf[(++sp->front)%(sp->n)];
    V(&sp->mutex);
    V(&sp->slots);
    return item;
}

//lecture note code: thread
void *thread(void *vargp)
{
    Pthread_detach(pthread_self());
    while(1)
    {
        int connfd=sbuf_remove(&sbuf);
        P(&client_mutex); //client_cnt 값은 thread_safe해야 하므로 별도의 lock을 잡아주어야 한다.
        client_cnt++;
        V(&client_mutex);

        check_threads(root,connfd);
        Close(connfd);

        P(&client_mutex);
        client_cnt--;
        if(!client_cnt)
        {
            FILE* fp=Fopen("stock.txt","w");
            inorder_print_file(fp,root);
            Fclose(fp);
        }
        V(&client_mutex);
                
    }
    return NULL;
}

//
item* init_sbuf(item* root, int listenfd, int n)
{
    FILE* fp=Fopen("stock.txt","r");
    int ID, left_stock,price;
    while(fscanf(fp,"%d%d%d",&ID,&left_stock,&price)!=EOF)
    {
        root=insert(root,ID,left_stock,price);
    }
    Fclose(fp);
    Sem_init(&client_mutex,0,1);
    sbuf_init(&sbuf,n);

    return root;
}

void init_once()
{
    Sem_init(&mutex,0,1);
    byte_cnt=0;
}


int main(int argc, char **argv) 
{
    int listenfd, connfd, i;
    socklen_t clientlen;
    struct sockaddr_storage clientaddr;  /* Enough space for any address */ 
    //char client_hostname[MAXLINE], client_port[MAXLINE];
    pthread_t tid;
    
    if (argc != 2) {
        fprintf(stderr, "usage: %s <port>\n", argv[0]);
        exit(0);
    }
    listenfd=Open_listenfd(argv[1]);
    root=init_sbuf(root,listenfd,SBUF_SIZE);
    //inorder_print_file(STDIN_FILENO,root);
    for(i=0; i<THREAD_MAX; i++)
    {
        Pthread_create(&tid, NULL, thread, NULL);
    }    
    
    while (1) {
        clientlen=sizeof(struct sockaddr_storage);
        connfd=Accept(listenfd, (SA *)&clientaddr, &clientlen);
        sbuf_insert(&sbuf,connfd);
    }
    item_free(root);
    exit(0);
}


void check_threads(item* root, int connfd)
{
    int n;
    char buf[MAXLINE],command[MAXLINE];
    int ID, amount;
    rio_t rio;
    static pthread_once_t once=PTHREAD_ONCE_INIT;
    Pthread_once(&once, init_once);
    Rio_readinitb(&rio, connfd);

    while((n=Rio_readlineb(&rio, buf, MAXLINE))!=0)
    {
        P(&mutex);
        byte_cnt+=n;
        printf("Thread received %d (%d total) byted on fd %d\n",n,byte_cnt,connfd);
        //printf("%s",buf);
        V(&mutex);
        sscanf(buf,"%s",command);
        if(!strcmp(command,"show"))
        {
            show(root,buf);
        }
        else
        {
            sscanf(buf,"%s%d%d",command,&ID,&amount);
            if(!strcmp(command,"sell"))
            {
                update(root, ID, amount,0,buf);
            }
            else if(!strcmp(command,"buy"))
            {
                update(root, ID, (-1)*amount,1,buf);
            }
        } 
        Rio_writen(connfd,buf,sizeof(buf));
        memset(buf,0,sizeof(buf));
    }
    printf("Thread %d exit\n",connfd);
}

item* create(int ID, int left_stock, int price)
{
    item* temp=(item*)malloc(sizeof(item));
    temp->ID=ID;
    temp->left_stock=left_stock;
    temp->price=price;
    temp->readcnt=0;
    temp->left_child=NULL;
    temp->right_child=NULL;
    Sem_init(&(temp->w),0,1);
    Sem_init(&(temp->mutex),0,1);
    return temp;
}

item* insert(item* cur, int ID, int left_stock, int price)
{
    if(cur==NULL) cur=create(ID,left_stock,price);
    else if(ID<cur->ID) cur->left_child=insert(cur->left_child,ID,left_stock,price);
    else cur->right_child=insert(cur->right_child,ID,left_stock,price);
    return cur;
}

int update(item* root, int ID, int amount, int flag, char* buf)
{
    if(root==NULL) return 0;
    if(root->ID==ID)
    {
        P(&(root->w)); 
        if(root->left_stock + amount >= 0)
        {
            if(flag) sprintf(buf,"[buy] success\n");
            else sprintf(buf,"[sell] success\n");
            root->left_stock+=amount;
            V(&(root->w));
            return 1;
        }
        else 
        {
            sprintf(buf,"Not enough left stock\n");
            V(&(root->w));
            return 0;
        }
    }
    else if(root->ID<ID) return update(root->right_child,ID,amount,flag,buf);
    else return update(root->left_child, ID, amount,flag,buf);
}

void show(item* root,char* buf)
{
    if(root==NULL) return; 
    char temp[MAXLINE];

    show(root->left_child,buf);
    
    P(&root->mutex);
    root->readcnt+=1;
    if(root->readcnt==1) P(&root->w);
    V(&root->mutex);

    sprintf(temp, "%d %d %d\n",root->ID,root->left_stock,root->price);
    strcat(buf,temp);

    P(&root->mutex);
    root->readcnt-=1;
    if(root->readcnt==0) V(&root->w);
    V(&root->mutex);
    
    show(root->right_child,buf);

    return;
}

void inorder_print_file(FILE* fp, item* root)
{
    if(root==NULL) return;
    inorder_print_file(fp,root->left_child);
    fprintf(fp,"%d %d %d\n",root->ID, root->left_stock, root->price);
    inorder_print_file(fp,root->right_child);
}

void item_free(item* root)
{
    if(root==NULL) return;
    item_free(root->left_child);
    item_free(root->right_child);
    free(root);
}

/* $end echoserverimain */
