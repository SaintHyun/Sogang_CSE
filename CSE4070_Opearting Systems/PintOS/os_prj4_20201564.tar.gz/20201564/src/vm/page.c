#include "vm/page.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "threads/palloc.h"
#include "userprog/pagedir.h"
#include "threads/malloc.h"
#include "filesys/file.h"
#include "lib/string.h"

void vm_init(struct hash *vm)
{
    hash_init(vm, vm_hash_find, vm_hash_compare, NULL);
}

static unsigned vm_hash_find(const struct hash_elem *elem, void *aux)
{
    struct vm_entry* entry=hash_entry(elem, struct vm_entry, helem);
    return hash_bytes(&entry->vaddr, sizeof(entry->vaddr));
}

static bool vm_hash_compare(const struct hash_elem *elem1, const struct hash_elem *elem2, void *aux)
{
    struct vm_entry* hash1=hash_entry(elem1, struct vm_entry, helem);
    struct vm_entry* hash2=hash_entry(elem2, struct vm_entry, helem);
    if(hash1->vaddr>hash2->vaddr) return true;
    else return false;
}

bool insert_vm_entry(struct hash *vm, struct vm_entry *entry)
{
    bool flag = hash_insert(vm, &(entry->helem));
    if(!flag) return true;
    return false;
}
bool delete_vm_entry(struct hash *vm, struct vm_entry *entry)
{
    bool flag = hash_delete(vm, &(entry->helem));
    if(!flag) return true;
    return false;
}

struct vm_entry *find_vm_entry(void *vaddr)
{
    struct vm_entry *temp = (struct vm_entry*)malloc(sizeof(struct vm_entry)); // 
    struct hash_elem *elem; //elem 변수
    struct hash *hvm = &(thread_current()->vm); 
    temp->vaddr = pg_round_down(vaddr); //vaddr의 page 번호
    elem = hash_find(hvm, &(temp->helem)); //hash_find로 hash_elem find
    if(elem==NULL) return NULL;
    else return hash_entry(elem, struct vm_entry, helem);//있으면 hash_entry return, 없으면 NULL 리턴
}

void vm_call_destroy(struct hash *vm)
{
    hash_destroy(vm, vm_destroy); //hash_destroy 함수 call
}

void vm_destroy(struct hash_elem *elem, void *aux)
{
    struct thread* cur=thread_current();
    struct vm_entry *entry=hash_entry(elem, struct vm_entry, helem);
    if(entry->isLoaded == true) //load 되어 있는 entry면
    {
        palloc_free_page(pagedir_get_page(cur->pagedir, entry->vaddr)); 
        pagedir_clear_page(cur->pagedir, entry->vaddr); // page 할당 해제 및 page mapping 해제
    }
    free(entry); //entry할당 해제
}

void check_buffer(void *buffer, unsigned size, void *esp, bool toWrite)
{
  struct vm_entry* entry;
  char* checkbuf=(char*)buffer;
  for(checkbuf=(char*)buffer; checkbuf<(char*)buffer+size; checkbuf++)
  {
    checkaddr(checkbuf,esp);
    entry=find_vm_entry(checkbuf);
    if(entry && toWrite && !entry->writable) exit(-1);
  }
}

void check_string(const void* str, void* esp)
{
  char* checkstr = (char*)str;
  checkaddr(checkstr,esp);
  checkstr++;
  for(checkstr=(char*)str; *checkstr!=0; checkstr++)
  {
    checkaddr(checkstr, esp); //문자열의 마지막까지 valid한 address인지 확인한다.
  } 
}

bool load_file(void *kaddr, struct vm_entry *entry)
{
    if((unsigned)file_read_at(entry->file,kaddr,entry->read_bytes, entry->offset) != entry->read_bytes) return false; 
    //file_read_at을 이용하여 readBytes만큼 데이터 작성, 작성할 수 없으면 false
    memset(kaddr + entry->read_bytes, 0, entry->zero_bytes); //초기화
    return true;
}
