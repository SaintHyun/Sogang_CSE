#ifndef VM_PAGE_H
#define VM_PAGE_H

#include <debug.h>
#include <list.h>
#include <stdint.h>
#include <hash.h>
#include "threads/palloc.h"

#define VM_BIN  0
#define VM_FILE 1
#define VM_ANON 2

struct vm_entry
{
    uint8_t type;
    void *vaddr;
    bool writable;

    bool isLoaded;
    struct file* file;

    size_t offset;
    size_t read_bytes;
    size_t zero_bytes;

    struct hash_elem helem;
};

void vm_init(struct hash* vm);
static unsigned vm_hash_find(const struct hash_elem *elem, void *aux);
static bool vm_hash_compare(const struct hash_elem *elem1, const struct hash_elem *elem2, void *aux);

bool insert_vm_entry(struct hash *vm, struct vm_entry *entry);
bool delete_vm_entry(struct hash *vm, struct vm_entry *entry);

struct vm_entry *find_vm_entry(void *vaddr);
void vm_call_destroy(struct hash *vm);
void vm_destroy(struct hash_elem *elem, void *aux);

void check_buffer(void *buffer, unsigned size, void *esp, bool toWrite);
void check_string(const void* str, void* esp);
bool load_file(void *kaddr, struct vm_entry *entry);

#endif
