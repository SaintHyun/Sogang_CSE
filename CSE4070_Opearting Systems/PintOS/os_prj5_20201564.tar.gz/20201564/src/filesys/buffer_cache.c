#include "filesys/buffer_cache.h"
#include "threads/palloc.h"
#include <string.h>
#include <debug.h>

#define BUFFER_CACHE_ENTRIES 64 // 캐시할 블록의 수


static struct buffer_head buffer_head[BUFFER_CACHE_ENTRIES]; // 실제 데이터를 제외한, 캐시 스스로에 대한 설명을 가지고 있음
static char buffer_cache[BUFFER_CACHE_ENTRIES * BLOCK_SECTOR_SIZE]; //실제 데이터가 저장되는 버퍼
static struct buffer_head *clock_hand; // clock 알고리즘 변수
static struct lock buffer_cache_lock; // lock
static void init_head (struct buffer_head *, void *);


void buffer_cache_init () // 버퍼 캐시 시스템 초기화
{
  struct buffer_head *head;
  void *cache = buffer_cache;
  for (head = buffer_head; head != buffer_head + BUFFER_CACHE_ENTRIES; head++, cache += BLOCK_SECTOR_SIZE)
  {
    init_head (head, cache);
  }
  clock_hand = buffer_head;
  lock_init (&buffer_cache_lock);
}

static void init_head (struct buffer_head *head, void *buffer)
{
  memset (head, 0, sizeof (struct buffer_head));
  lock_init (&head->lock);
  head->buffer = buffer;
}

void buffer_cache_terminate (void)
{
  struct buffer_head *head;
  for (head = buffer_head; head != buffer_head + BUFFER_CACHE_ENTRIES; head++)
  {
    lock_acquire (&head->lock);
    buffer_cache_flush_entry (head);
    lock_release (&head->lock);
  }
}

bool buffer_cache_read (block_sector_t sector_idx, void *buffer, off_t bytes_read, int chunk_size, int sector_ofs)
{
  struct buffer_head *head;
  if (!(head = buffer_cache_lookup (sector_idx)))
  {
    // buffer에 sector 없음
    head = buffer_cache_select_victim (); // 캐시에서 제거할 섹터가 있다
    buffer_cache_flush_entry (head);
    head->dirty = false; //read 했으므로 dirty bit false
    head->valid = true;
    head->address = sector_idx;
    lock_release (&buffer_cache_lock); // address 지정 -> lock release
    block_read (fs_device, sector_idx, head->buffer); // 실제 읽기 작업
  }
  head->clock = true;
  memcpy (buffer + bytes_read, head->buffer + sector_ofs, chunk_size); // 버퍼에서 읽기 작업
  lock_release (&head->lock);
  return true;
}

bool buffer_cache_write (block_sector_t sector_idx, void *buffer, off_t bytes_written, int chunk_size, int sector_ofs)
{
  struct buffer_head *head;
  if (!(head = buffer_cache_lookup (sector_idx)))
  {
    // buffer에 sector 없음
    head = buffer_cache_select_victim (); //캐시에서 제거할 섹터가 있다
    buffer_cache_flush_entry (head);
    head->valid = true;
    head->address = sector_idx;
    lock_release (&buffer_cache_lock); // address 지정 -> lock release
    block_read (fs_device, sector_idx, head->buffer); // 실제 읽기 작업
  }
  head->clock = true;
  head->dirty = true; // write 됐으므로 dirty bit true
  memcpy (head->buffer + sector_ofs, buffer + bytes_written, chunk_size); // 버퍼에서 쓰기 작업
  lock_release (&head->lock);
  return true;
}

struct buffer_head* buffer_cache_lookup (block_sector_t sector)
{
  lock_acquire (&buffer_cache_lock); //lock을 걸지 않으면 같은 sector에 대한 cache가 여러 개 생성 될 가능성이 있다.
  struct buffer_head *head;
  for (head = buffer_head; head != buffer_head + BUFFER_CACHE_ENTRIES; head++)
  {
    if (head->valid && head->address == sector) //cache hit
    {
      lock_acquire (&head->lock); //buffer head에 대한 lock acquire
      lock_release (&buffer_cache_lock); //기존 lock은 해제
      return head;
    }
  }
  return NULL; //cache miss이므로 lock을 release하면 안된다.
}

struct buffer_head* buffer_cache_select_victim (void)
{
  while(1)
  {
    for (clock_hand = clock_hand ; clock_hand != buffer_head + BUFFER_CACHE_ENTRIES; clock_hand++)
    {
      lock_acquire (&clock_hand->lock);
      if (!clock_hand->valid || !clock_hand->clock) return clock_hand++; 
      clock_hand->clock = false;
      lock_release (&clock_hand->lock);   
    }
    clock_hand = buffer_head;
  }
}

void buffer_cache_flush_entry (struct buffer_head *entry)
{
  if (!entry->valid || !entry->dirty) return; //사용 중이 아니거나 dirty하지 않으면 flush할 필요가 없다.
  entry->dirty = false;
  block_write (fs_device, entry->address, entry->buffer);
}