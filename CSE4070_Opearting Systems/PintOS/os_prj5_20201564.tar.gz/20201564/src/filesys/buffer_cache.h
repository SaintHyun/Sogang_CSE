#ifndef FILESYS_BUFFER_CACHE_H
#define FILESYS_BUFFER_CACHE_H

#include "filesys/filesys.h"
#include "filesys/inode.h"
#include "threads/synch.h"

struct buffer_head
  {
    bool dirty;
    bool valid;
    block_sector_t address; //entry의 dist sector 주소
    bool clock; //clock 알고리즘
    struct lock lock; //lock 변수
    void *buffer; //buffer를 가리키는 포인터
  };

void buffer_cache_init (void);
void buffer_cache_terminate (void);
bool buffer_cache_read (block_sector_t, void *, off_t, int, int);
bool buffer_cache_write (block_sector_t, void *, off_t, int, int);
struct buffer_head *buffer_cache_lookup (block_sector_t);
struct buffer_head *buffer_cache_select_victim (void);
void buffer_cache_flush_entry (struct buffer_head *);
bool buffer_cache_ok (void);
#endif