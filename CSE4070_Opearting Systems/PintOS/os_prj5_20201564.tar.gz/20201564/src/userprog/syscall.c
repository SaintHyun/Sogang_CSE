#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "threads/synch.h"
#include "filesys/off_t.h"
#include "filesys/inode.h"
#include "filesys/directory.h"
#include "filesys/file.h"
#include "filesys/filesys.h"

static void syscall_handler (struct intr_frame *);
struct lock filesys_lock;
struct file
{
  struct inode *inode;        
  off_t pos;                 
  bool deny_write;           
};

struct file *
process_get_file (int fd)
{
  struct thread *t = thread_current ();
  if (fd <= 1 || t->next_fd <= fd)
    return NULL;
  return t->fd[fd];
}

void
syscall_init (void) 
{
  lock_init(&filesys_lock);
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

void check(const void *vaddr) 
{
  struct thread *t=thread_current();
  if (!is_user_vaddr(vaddr) || pagedir_get_page(t->pagedir, vaddr) == NULL) exit(-1);
}

static void
syscall_handler (struct intr_frame *f) 
{
  check(f->esp);
  switch (*(uint32_t *)(f->esp)) 
  {
    case SYS_HALT:
      halt();
      break;
    case SYS_EXIT:
      check(f->esp + 4);
      exit(*(uint32_t *)(f->esp + 4));
      break;
    case SYS_EXEC:
      check(f->esp + 4);
       f->eax =exec((const char *)*(uint32_t *)(f->esp + 4));
      break; 
    case SYS_WAIT:
      check(f->esp + 4);
      f->eax = wait((pid_t)*(uint32_t *)(f->esp + 4));
      break; 
    case SYS_READ:
      check(f->esp + 4);
      check(f->esp + 8);
      check(f->esp + 12);
       f->eax =read((int)*(uint32_t *)(f->esp+4), (void *)*(uint32_t *)(f->esp + 8), (unsigned)*((uint32_t *)(f->esp + 12)));
      break;
    case SYS_WRITE:
      check(f->esp + 4);
      check(f->esp + 8);
      check(f->esp + 12);
      f->eax=write((int)*(uint32_t *)(f->esp+4), (void *)*(uint32_t *)(f->esp + 8), (unsigned)*((uint32_t *)(f->esp + 12)));
      break;

    //prj1: additional
    case SYS_FIBONACCI:
      check(f->esp + 4);
      f->eax=fibonacci(*(int*)(f->esp+4));
      break;
    case SYS_MAX_OF_FOUR_INT:
      check(f->esp + 4);
      check(f->esp + 8);
      check(f->esp + 12);
      check(f->esp + 16);
      f->eax=max_of_four_int(*(int *)(f->esp+4), *(int *)(f->esp+8), *(int *)(f->esp+12), *(int *)(f->esp+16));
      break;

    //prj2
    case SYS_CREATE:
      check(f->esp + 4);
      check(f->esp + 8);
      f->eax = create((const char *)*(uint32_t *)(f->esp + 4), (unsigned)*(uint32_t *)(f->esp + 8));
      break;
    case SYS_REMOVE:
      check(f->esp + 4);
      f->eax = remove((const char*)*(uint32_t *)(f->esp + 4));
      break;
    case SYS_OPEN:
      check(f->esp + 4);
      f->eax = open((const char*)*(uint32_t *)(f->esp + 4));
      break;
    case SYS_FILESIZE:
      check(f->esp + 4);
      f->eax = filesize((int)*(uint32_t *)(f->esp + 4));
      break;
    case SYS_SEEK:
      check(f->esp + 4);
      check(f->esp + 8);
      seek((int)*(uint32_t *)(f->esp + 4), (unsigned)*(uint32_t *)(f->esp + 8));
      break;
    case SYS_TELL:
      check(f->esp + 4);
      f->eax = tell((int)*(uint32_t *)(f->esp + 4));
      break;
    case SYS_CLOSE:
      check(f->esp + 4);
      close((int)*(uint32_t *)(f->esp + 4));
      break;
    case SYS_MKDIR:
      //check(f->esp+4);
      f->eax = mkdir ((char*)*(uint32_t*)(f->esp+4));
      break;
    case SYS_CHDIR:
      check(f->esp+4);
      f->eax = chdir ((char*)*(uint32_t*)(f->esp+4));
      break;
    case SYS_READDIR:
      check(f->esp+4);
      check(f->esp+8);
      f->eax = readdir ((int)*(uint32_t *)(f->esp+4), (char*)*(uint32_t*)(f->esp+8));
      break;
    case SYS_ISDIR: 
      check(f->esp+4);
      f->eax = isdir ((int)*(uint32_t *)(f->esp+4));
      break;
    case SYS_INUMBER:
      check(f->esp+4);
      f->eax = inumber ((int)*(uint32_t *) (f->esp+4));
      break;
  }
  //printf ("system call!\n");
  //thread_exit ();
}

void halt (void) 
{
  shutdown_power_off();
}

void exit (int status) 
{
  printf("%s: exit(%d)\n", thread_name(), status);
  thread_current() -> exit_status = status;
  for (int i = 3; i < 128; i++) 
  {
    if (thread_current()->fd[i] != NULL) close(i);     
  }
  thread_exit();   
}

pid_t exec (const char *cmd_line) 
{
  return process_execute(cmd_line);
}

int wait (pid_t pid) 
{
  return process_wait(pid);
}


int fibonacci(int a)
{
  int fibo[3]={0,1,0};
  if(a<=0) exit(-1); //양수만 가능
  if(a==1) return 0;
  int i;
  for(i=0; i<a-1; i++)
  {
    fibo[2]=fibo[0]+fibo[1];
    fibo[0]=fibo[1];
    fibo[1]=fibo[2];
  }
  return fibo[2];
}

int max_of_four_int(int a, int b, int c, int d)
{
	int max=-0x7FFFFFFF;
	if(a>b) max = a;
	else max = b;
	if(c>max) max = c;
	if(d>max) max = d;
	return max;
}



bool create (const char *file, unsigned initial_size) 
{
  if (file == NULL) exit(-1);
  check(file);
  return filesys_create(file, initial_size);
}

bool remove (const char *file) 
{
  if (file == NULL) exit(-1);
  check(file);
  return filesys_remove(file);
}

int filesize (int fd) 
{
  if(thread_current()->fd[fd]==NULL) exit(-1);
  return file_length(thread_current()->fd[fd]);
}

int open (const char *file) 
{
  int i;
  int ret = -1;
  struct file* fp;
  if (file == NULL) exit(-1);
  check(file);
  lock_acquire(&filesys_lock);
  fp = filesys_open(file);
  if (fp == NULL) ret = -1;
  else 
  {
    for (i = 3; i < 128; i++) 
    {
      if (thread_current()->fd[i] == NULL)
      {
        if (strcmp(thread_current()->name, file) == 0) file_deny_write(fp);
        thread_current()->fd[i] = fp;
        ret = i;
        break;
      }
    }
  }
  lock_release(&filesys_lock);
  return ret;
}

int read (int fd, void* buffer, unsigned size) 
{
  int i;
  int ret;
  check(buffer);
  lock_acquire(&filesys_lock);
  if (fd == 0) 
  {
    for (i = 0; i < size; i ++) 
    {
      if (((char *)buffer)[i] == '\0') break;
    }
    ret = i;
  } 
  else if (fd > 2) 
  {
    if (thread_current()->fd[fd] == NULL) exit(-1);
    ret = file_read(thread_current()->fd[fd], buffer, size);
  }
  lock_release(&filesys_lock);
  return ret;
}

int write (int fd, const void *buffer, unsigned size) 
{
  int ret = -1;
  check(buffer);
  lock_acquire(&filesys_lock);
  if (fd == 1) 
  {
    putbuf(buffer, size);
    ret = size;
  } 
  else if (fd > 2) 
  {
    if (thread_current()->fd[fd] == NULL) 
    {
      lock_release(&filesys_lock);
      exit(-1);
    }
    if (thread_current()->fd[fd]->deny_write) file_deny_write(thread_current()->fd[fd]);
    ret = file_write(thread_current()->fd[fd], buffer, size);
  }
  lock_release(&filesys_lock);
  return ret;
}

void seek (int fd, unsigned position) 
{
  if (thread_current()->fd[fd] == NULL) exit(-1);
  file_seek(thread_current()->fd[fd], position);
}

unsigned tell (int fd) 
{
  if (thread_current()->fd[fd] == NULL) exit(-1);
  return file_tell(thread_current()->fd[fd]);
}

void close (int fd) 
{
  struct file* fp;
  fp=thread_current()->fd[fd];
  if (fp == NULL) exit(-1);
  fp=thread_current()->fd[fd];
  thread_current()->fd[fd]=NULL;
  return file_close(fp);
}

bool chdir (const char *path_o)
{
  char path[PATH_MAX_LEN + 1];
  strlcpy (path, path_o, PATH_MAX_LEN);
  strlcat (path, "/0", PATH_MAX_LEN);

  char name[PATH_MAX_LEN + 1];
  struct dir *dir = parse_path (path, name);
  if (!dir) return false;
  
  dir_close (thread_current ()->working_dir);
  thread_current ()->working_dir = dir;
  return true;
}

bool mkdir (const char *dir)
{
  return filesys_create_directory (dir);
}

bool readdir (int fd, char *name)
{
  struct file *f = process_get_file (fd);
  if (f == NULL) exit (-1);
  struct inode *inode = file_get_inode (f);
  if (!inode || !inode_is_directory (inode)) return false;
  struct dir *dir = dir_open (inode);
  if (!dir) return false; 
  int i;
  bool result = true;
  off_t *pos = (off_t *)f + 1;
  for (i = 0; i <= *pos && result; i++) result = dir_readdir (dir, name);
  if (i <= *pos == false) (*pos)++;
  dir_close (dir);
  return result;
}

bool
isdir (int fd)
{
  struct file *f = process_get_file (fd);
  if (f == NULL) exit (-1);
  return inode_is_directory (file_get_inode (f));
}

int
inumber (int fd)
{
  struct file *f = process_get_file (fd);
  if (f == NULL) exit (-1);
  return inode_get_inumber (file_get_inode (f));
}