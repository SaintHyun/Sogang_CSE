#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "threads/synch.h"

static void syscall_handler (struct intr_frame *);

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

void check(const void *vaddr) 
{
  struct thread *t=thread_current();
  if (!is_user_vaddr(vaddr) || pagedir_get_page(t->pagedir, vaddr) == NULL) exit(-1);
}

static void
syscall_handler (struct intr_frame *f) 
{
  check(f->esp);
  switch (*(uint32_t *)(f->esp)) 
  {
    case SYS_HALT:
      halt();
      break;
    case SYS_EXIT:
      check(f->esp + 4);
      exit(*(uint32_t *)(f->esp + 4));
      break;
    case SYS_EXEC:
      check(f->esp + 4);
       f->eax =exec((const char *)*(uint32_t *)(f->esp + 4));
      break; 
    case SYS_WAIT:
      check(f->esp + 4);
      f->eax = wait((pid_t)*(uint32_t *)(f->esp + 4));
      break; 
    case SYS_READ:
      check(f->esp + 4);
      check(f->esp + 8);
      check(f->esp + 12);
       f->eax =read((int)*(uint32_t *)(f->esp+4), (void *)*(uint32_t *)(f->esp + 8), (unsigned)*((uint32_t *)(f->esp + 12)));
      break;
    case SYS_WRITE:
      check(f->esp + 4);
      check(f->esp + 8);
      check(f->esp + 12);
      f->eax=write((int)*(uint32_t *)(f->esp+4), (void *)*(uint32_t *)(f->esp + 8), (unsigned)*((uint32_t *)(f->esp + 12)));
      break;
    case SYS_FIBONACCI:
      check(f->esp + 4);
      f->eax=fibonacci(*(int*)(f->esp+4));
      break;
    case SYS_MAX_OF_FOUR_INT:
      check(f->esp + 4);
      check(f->esp + 8);
      check(f->esp + 12);
      check(f->esp + 16);
      f->eax=max_of_four_int(*(int *)(f->esp+4), *(int *)(f->esp+8), *(int *)(f->esp+12), *(int *)(f->esp+16));
      break;
  }
  //printf ("system call!\n");
  //thread_exit ();
}

void halt (void) 
{
  shutdown_power_off();
}

void exit (int status) 
{
    printf("%s: exit(%d)\n", thread_name(), status);
    thread_current() -> exit_status = status;
    thread_exit ();
}

pid_t exec (const char *cmd_line) 
{
  return process_execute(cmd_line);
}

int wait (pid_t pid) 
{
  return process_wait(pid);
}

int read (int fd, void* buffer, unsigned size) 
{
  int i;
  if (fd == 0) 
  {
    for (i = 0; i < size; i ++) 
    {
      if (((char *)buffer)[i] == '\0') {
        break;
      }
    }
  }
  return i;
}

int write (int fd, const void *buffer, unsigned size) 
{
  if (fd == 1) 
  {
    putbuf(buffer, size);
    return size;
  }
  return -1;
}

int fibonacci(int a)
{
  int fibo[3]={0,1,0};
  if(a<=0) exit(-1); //양수만 가능
  if(a==1) return 0;
  int i;
  for(i=0; i<a-1; i++)
  {
    fibo[2]=fibo[0]+fibo[1];
    fibo[0]=fibo[1];
    fibo[1]=fibo[2];
  }
  return fibo[2];
}

int max_of_four_int(int a, int b, int c, int d)
{
	int max=-0x7FFFFFFF;
	if(a>b) max = a;
	else max = b;
	if(c>max) max = c;
	if(d>max) max = d;
	return max;
}