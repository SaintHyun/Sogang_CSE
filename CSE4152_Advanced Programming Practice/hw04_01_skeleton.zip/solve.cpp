#include "EnvGame.h"

vector<int> solve(EnvGame &a){
    int n = a.getNodeN();
    vector<int> ans;
    vector<int> check;
    
    ans.resize(n);

    vector<vector<int>> map;

    map.resize(n);
    for(int j=0;j<n;j++) {map[j].clear();map[j].reserve(5);}

    for(int i=0;i<n;i+=2){

        int ni = (i+1) % n ;

        a.cleanAllWires();
        a.connectWire ( i, ni);
        a.goToOtherSide();
 
        for(int j=0;j<n;j++){            
            for(int k=j+1;k<n;k++){
 
                bool light = a.checkConnectivity(j,k);
                
                if (light){
                     map[i].push_back(j);
                     map[i].push_back(k);
                     map[ni].push_back(j);
                     map[ni].push_back(k);
                }
            }
        }
        a.goToOtherSide();
    }

    for(int i=1;i<n;i+=2){
        int ni  = (i+1)%n ;
        a.cleanAllWires();

        a.connectWire ( i,ni );

        a.goToOtherSide();
 
        for(int j=0;j<n;j++){            
            for(int k=j+1;k<n;k++){
 
                bool light = a.checkConnectivity(j,k);
                
                if (light){
                     if( std::find (map[i].begin(), map[i].end(), j) != map[i].end() )
                        ans[i]=j;
                     if( std::find (map[i].begin(), map[i].end(), k) != map[i].end() )
                        ans[i]=k;
                     if( std::find (map[ni].begin(), map[ni].end(), j) != map[ni].end() )
                        ans[ni]=j;
                     if( std::find (map[ni].begin(), map[ni].end(), k) != map[ni].end() )
                        ans[ni]=k;
                }
            }
        }
        a.goToOtherSide();
    }
    return ans;
}
