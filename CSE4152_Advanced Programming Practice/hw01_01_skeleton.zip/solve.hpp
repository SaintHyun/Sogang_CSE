#pragma once

#include "party.hpp"
#include <vector>
#include <map>
#include <set>
#include <string>

using namespace std;

int solve(Party *party);
