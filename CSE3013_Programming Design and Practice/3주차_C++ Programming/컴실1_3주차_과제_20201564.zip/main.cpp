#include "Str.h"
#include <iostream>
using namespace std;

int main(void)
{
	Str a("I'm a girl111111111111111111111111111111111");
	cout <<"a contents " << a.contents() << endl;
	Str b(1000);
	b="I'm a boy1111111111111111111";
	cout << "b contents " << b.contents() << endl;
	cout << "compare1 " << a.compare("I'm a girl") << endl;
	cout << "compare2 " << a.compare("Q'm a boy") << endl;
	cout << "compare3 " << a.compare(b) << endl;
	cout << "a length " << a.length() << endl;
	cout << "b length " << b.length() << endl;
	a=b;
	cout << a.contents() << endl;
	cout << a.compare(b) << endl;
}
