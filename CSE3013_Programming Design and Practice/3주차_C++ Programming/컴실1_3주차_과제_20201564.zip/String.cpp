#include<iostream>
#include "Str.h"
#include<cstdlib>

using namespace std;

Str::Str(int leng)
{
	if(leng<0) cout << "Length Error" << endl;
	else
	{
		len=leng;
		str=new char[len+5]; // 크기 여유를 위해 다섯 칸 추가 확보 (본인의 습관)
	}
}

Str::Str(char *neyong)
{
	len=strlen(neyong);
	str=new char[len+5]; //역시 크기 5를 여유있게 더 확보한다.
	strcpy(str,neyong);
}

Str::~Str()
{
	delete str;
}

int Str::length()
{
	return strlen(str);
}

char* Str::contents()
{
	return str;
}

int Str::compare(class Str& a)
{
	if(strcmp(str,a.str)>0) return 1;
	if(strcmp(str,a.str)==0) return 0;
	if(strcmp(str,a.str)<0) return -1;
}

int Str::compare(char *a)
{
	if(strcmp(str,a)>0) return 1;
	if(strcmp(str,a)==0) return 0;
	if(strcmp(str,a)<0) return -1;
}

void Str::operator= (char *a)
{
	str=new char[strlen(a)+5];
	strcat(str,a);
}

void Str::operator= (class Str& a)
{
	str=new char[strlen(a.str)+5];
	strcat(str,a.str);
}

