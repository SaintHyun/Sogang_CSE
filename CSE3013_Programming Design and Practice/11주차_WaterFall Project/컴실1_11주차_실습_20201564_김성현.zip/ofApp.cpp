#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup() {
	ofSetFrameRate(15); // Limit the speed of our program to 15 frames per second

	// We still want to draw on a black background, so we need to draw
	// the background before we do anything with the brush
	ofBackground(255, 255, 255);
	ofSetLineWidth(4);

	draw_flag = 0;
	load_flag = 0;
	water_flag = 0;
	length = 0;
	nowline = -1;
	fall = 0;
	slope = 0;
	dot_diameter = 20.0f;
	ndot = 0;
}

double ofApp::Slope(double x, double y)
{
	int i;
	if (nowline == -1)
	{
		for (i = 0; i < num_of_line; i++)
		{
			if ((y > min(posline[i][1], posline[i][3]) && (y < max(posline[i][1], posline[i][3])))) // select bottom line
			{
				if (x > posline[i][0] && x < posline[i][2])
				{
					slope = (double)(posline[i][2] - posline[i][0]) / (double)(posline[i][3] - posline[i][1]);
					fall = (double)(x - posline[i][0]) / slope + posline[i][1];
					if (fall > y) 
					{
						nowline = i;
						return 0;
					}
				}
			}
		}
		if (i == num_of_line)
		{
			fall = 0;
			slope = 0;
		}
	}
	else
	{
		if (y >= fall && y <= max(posline[nowline][1], posline[nowline][3])) return slope;
		else
		{
			if (y >= max(posline[nowline][1], posline[nowline][3])) nowline = -1;
			return 0;
		}
	}
	if (nowline == -1) return 0;
}

//--------------------------------------------------------------
void ofApp::update() {
	int i;
	double x, y, s;
	if (water_flag)
	{
		length = water.size();
		y = water[length - 1].position.y;
		x = water[length - 1].position.x;
		s = Slope(x, y);
		if (y <= ofGetHeight() - 40) water.push_back(Water(x + s, y + 1));
	}
}
//--------------------------------------------------------------
void ofApp::draw() {
	ofSetColor(127, 23, 31);  // Set the drawing color to brown

	// Draw shapes for ceiling and floor
	ofDrawRectangle(0, 0, 1024, 40); // Top left corner at (50, 50), 100 wide x 100 high
	ofDrawRectangle(0, 728, 1024, 40); // Top left corner at (50, 50), 100 wide x 100 high
	ofSetLineWidth(5);
	int i;
	ofSetLineWidth(5);
	if (draw_flag)
	{
		for (i = 0; i < num_of_line; i++)
		{
			ofDrawLine(posline[i][0], posline[i][1], posline[i][2], posline[i][3]);
		}
		for (i = 0; i < num_of_dot; i++)
		{
			if (ndot == i)
			{
				ofSetColor(255, 0, 0);
			}
			else
			{
				ofSetColor(0, 0, 0);
			}
			ofDrawCircle(posdot[i][0], posdot[i][1], dot_diameter);
		}

		/* COMSIL1-TODO 3 : Draw the line segment and dot in which water starts to flow in the screen.
		 Note that after drawing line segment and dot, you have to make selected water start dot colored in red.
		 */

		if (water_flag)
		{
			for (i = 0; i < water.size(); i++)
			{
				water[i].draw();
			}
		}

		 // 2nd week portion.
		ofSetLineWidth(2);
	}
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key) {
	int i;

	if (key == 'v') {
		// HACK: only needed on windows, when using ofSetAutoBackground(false)
		glReadBuffer(GL_FRONT);
		ofSaveScreen("savedScreenshot_" + ofGetTimestampString() + ".png");
	}
	if (key == 'q') { //exit program
		// Reset flags
		draw_flag = 0;
		
		for (i = 0; i < num_of_line; i++)
		{
			delete posline[i];
		}
		delete posline;
		for (i = 0; i < num_of_dot; i++)
		{
			delete posdot[i];
		}
		delete posdot;

		// Free the dynamically allocated memory exits.
		cout << "Dynamically allocated memory has been freed." << endl;
		_Exit(0);
	}
	if (key == 'd') {
		if (!load_flag) return;
		draw_flag = 1;
		/* COMSIL1-TODO 2: This is draw control part.
		You should draw only after when the key 'd' has been pressed.
		*/
	}
	if (key == 's') {
		water_flag = 1;
		if (!first) // first waterFall causes always error. So only first Fall resets coordinates.
		{
			water.push_back(Water(fx, fy));
			first=1;
		}
		// 2nd week portion.
	}
	if (key == 'e') {
		water_flag = 0;
		water.clear();
		// 2nd week portion.
	}
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key) {
	if (key == 'l') {
		// Open the Open File Dialog
		ofFileDialogResult openFileResult = ofSystemLoadDialog("Select a only txt for Waterfall");

		// Check whether the user opened a file
		if (openFileResult.bSuccess) {
			ofLogVerbose("User selected a file");

			// We have a file, so let's check it and process it
			processOpenFileSelection(openFileResult);
			load_flag = 1;
		}
	}

	/* COMSIL1-TODO 4: This is selection dot control part.
	 You can select dot in which water starts to flow by left, right direction key (<- , ->).
	 */

	if (key == OF_KEY_RIGHT) {
		if (!water_flag) //during falling, can't change the ndot
		{
			ndot++;
			if (ndot == num_of_dot)
			{
				ndot = 0;
			}
			nowline = -1;
			water.clear();
			water.push_back(Water(posdot[ndot][0], posdot[ndot][1])); // reset coordinate
			cout << "Selcted Dot Coordinate is (" << posdot[ndot][0] << ", " << posdot[ndot][1] << ")" << endl;
		}
		
	}
	if (key == OF_KEY_LEFT) {
		if (!water_flag)
		{
			ndot--;
			if (ndot == -1)
			{
				ndot = num_of_dot-1;
			}
			nowline = -1;
			water.clear();
			water.push_back(Water(posdot[ndot][0], posdot[ndot][1]));
			cout << "Selcted Dot Coordinate is (" << posdot[ndot][0] << ", " << posdot[ndot][1] << ")" << endl;
		}
		
	}
}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y) {

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button) {

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button) {

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button) {

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y) {

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y) {

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h) {

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg) {

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo) {

}

void ofApp::processOpenFileSelection(ofFileDialogResult openFileResult) {
	//Path to the comma delimited file
	//string fileName = "input.txt";

	string fileName = openFileResult.getName();
	ofFile file(fileName);

	if (!file.exists()) cout << "Target file does not exists." << endl;
	else cout << "We found the target file." << endl;

	ofBuffer buffer(file);

	/* This variable is for indicating which type of input is being received.
	 IF input_type == 0, then work of getting line input is in progress.
	 IF input_type == 1, then work of getting dot input is in progress.
	 */
	int input_type = 0;
	int count = 0, i = 0;

	/* COMSIL1-TODO 1 : Below code is for getting the number of line and dot, getting coordinates.
	 You must maintain those information. But, currently below code is not complete.
	 Also, note that all of coordinate should not be out of screen size.
	 However, all of coordinate do not always turn out to be the case.
	 So, You have to develop some error handling code that can detect whether coordinate is out of screen size.
	*/


	// Read file line by line
	for (ofBuffer::Line it = buffer.getLines().begin(), end = buffer.getLines().end(); it != end; ++it) {
		string line = *it;

		// Split line into strings
		vector<string> words = ofSplitString(line, " ");

		if (words.size() == 1) {
			if (input_type == 0) { // Input for the number of lines.
				num_of_line = atoi(words[0].c_str());
				cout << "The number of line is: " << num_of_line << endl;
				posline = new int* [num_of_line];
				for (i = 0; i < num_of_line; i++)
				{
					posline[i] = new int[4];
				}
			}
			else { // Input for the number of dots.
				num_of_dot = atoi(words[0].c_str());
				cout << "The number of dot is: " << num_of_dot << endl;
				posdot = new int* [num_of_dot];
				for (i = 0; i < num_of_dot; i++)
				{
					posdot[i] = new int[2];
				}
			}
		}
		else if (words.size() >= 2) {
			int x1, y1, x2, y2;
			if (input_type == 0) { // Input for actual information of lines
				x1 = atoi(words[0].c_str());
				y1 = atoi(words[1].c_str());
				x2 = atoi(words[2].c_str());
				y2 = atoi(words[3].c_str());
				if (x1 < 0 || x1 > 1024 || y1 < 0 || y1 > 768 || x2 < 0 || x2 > 1024 || y2 < 0 || y2 > 768)
				{
					_Exit(0);
				}
				posline[count][0] = x1;
				posline[count][1] = y1;
				posline[count][2] = x2;
				posline[count][3] = y2;
				count++;
				if (count == num_of_line)
				{
					input_type = 1;
					count = 0;
				}
			}
			else { // Input for actual information of dots.
				x1 = atoi(words[0].c_str());
				y1 = atoi(words[1].c_str());
				if (x1 < 0 || x1 > 1024 || y1 < 0 || y1 > 768)
				{
					_Exit(0);
				}
				if (count == 0)  //for first coordinate, I want to save the value for first fall
				{
					fx = x1;
					fy = y1;
				}
				posdot[count][0] = x1;
				posdot[count][1] = y1;
				count++;
			}
		} // End of else if.
	} // End of for-loop (Read file line by line).

	//initializeWaterLines();
}

void ofApp::initializeWaterLines() {
	;
}


