#pragma once

#include "ofMain.h"

class Water
{
	public:
		Water(double x, double y)
		{
			position.set(x, y);
		}
		void draw()
		{
			ofSetColor(0, 0, 225);
			ofDrawCircle(position.x, position.y, 5);
		}
		ofPoint position;
};

class ofApp : public ofBaseApp {

public:
	void setup();
	void update();
	void draw();

	void keyPressed(int key);
	void keyReleased(int key);
	void mouseMoved(int x, int y);
	void mouseDragged(int x, int y, int button);
	void mousePressed(int x, int y, int button);
	void mouseReleased(int x, int y, int button);
	void mouseEntered(int x, int y);
	void mouseExited(int x, int y);
	void windowResized(int w, int h);
	void dragEvent(ofDragInfo dragInfo);
	void gotMessage(ofMessage msg);
	double Slope(double x, double y);
	/* WaterFall-related member variables Regions */
	int** posline;
	int** posdot;
	// flag variables
	int draw_flag;
	int load_flag;
	int water_flag;
	int ndot;
	int first = 0;
	double fx, fy;

	// Line segment and dot related variables
	int num_of_line, num_of_dot;
	float dot_diameter;

	/* WaterFall-related member functions */
	int nowline, length;
	double fall,slope;

	void processOpenFileSelection(ofFileDialogResult openFileResult);
	void initializeWaterLines(); // 2nd week portion.

	vector<Water> water;
};
