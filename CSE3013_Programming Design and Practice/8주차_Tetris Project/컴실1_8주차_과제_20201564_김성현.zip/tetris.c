#include "tetris.h"

static struct sigaction act, oact;

int main(){
	int exit=0;

	initscr();
	noecho();
	keypad(stdscr, TRUE);

	srand((unsigned int)time(NULL));

	createRankList();

	while(!exit){
		clear();
		switch(menu()){
		case MENU_PLAY: play(); break;
		case MENU_RANK: rank(); break;
		case MENU_RECM: recommendedPlay(); break;
		case MENU_EXIT: exit=1; break;
		default: break;
		}
	}

	endwin();
	system("clear");
	return 0;
}

void InitTetris(){
	int i,j;

	for(j=0;j<HEIGHT;j++)
		for(i=0;i<WIDTH;i++)
			field[j][i]=0;

	nextBlock[0]=rand()%7;
	nextBlock[1]=rand()%7;
	nextBlock[2]=rand()%7; //6주차 과제로 추가된 라인
	nextBlock[3]=rand()%7;
	blockRotate=0;
	blockY=-1;
	blockX=WIDTH/2-2;
	score=0;
	gameOver=0;
	timed_out=0;

	recRoot=(RecNode*)malloc(sizeof(RecNode));
	recRoot->lv=0;
	recRoot->score=0;
	for(i=0; i<HEIGHT; i++)
	{
		for(j=0; j<WIDTH; j++)
		{
			recRoot->f[i][j]=0;
		}
	}
	modified_recommend(recRoot); //9주차 추가, 추천 시스템의 초기 head포인터 생성

	DrawOutline();
	DrawField();
	DrawBlock(blockY,blockX,nextBlock[0],blockRotate,' ');
	DrawNextBlock(nextBlock);
	PrintScore(score);
}

void DrawOutline(){
	int i,j;
	/* 블럭이 떨어지는 공간의 태두리를 그린다.*/
	DrawBox(0,0,HEIGHT,WIDTH);

	/* next block을 보여주는 공간의 태두리를 그린다.*/
	move(2,WIDTH+10);
	printw("NEXT BLOCK");
	DrawBox(3,WIDTH+10,4,8);
	DrawBox(9,WIDTH+10,4,8); // 다다음 블록이 보여지는 테두리 추가(6주차 과제)

	/* score를 보여주는 공간의 태두리를 그린다.*/
	move(16,WIDTH+10);
	printw("SCORE");
	DrawBox(17,WIDTH+10,1,8);
}

int GetCommand(){
	int command;
	command = wgetch(stdscr);
	switch(command){
	case KEY_UP:
		break;
	case KEY_DOWN:
		break;
	case KEY_LEFT:
		break;
	case KEY_RIGHT:
		break;
	case ' ':	/* space key*/
		/*fall block*/
		break;
	case 'q':
	case 'Q':
		command = QUIT;
		break;
	default:
		command = NOTHING;
		break;
	}
	return command;
}

int ProcessCommand(int command){
	int ret=1;
	int drawFlag=0;
	switch(command){
	case QUIT:
		ret = QUIT;
		break;
	case KEY_UP:
		if((drawFlag = CheckToMove(field,nextBlock[0],(blockRotate+1)%4,blockY,blockX)))
			blockRotate=(blockRotate+1)%4;
		break;
	case KEY_DOWN:
		if((drawFlag = CheckToMove(field,nextBlock[0],blockRotate,blockY+1,blockX)))
			blockY++;
		break;
	case KEY_RIGHT:
		if((drawFlag = CheckToMove(field,nextBlock[0],blockRotate,blockY,blockX+1)))
			blockX++;
		break;
	case KEY_LEFT:
		if((drawFlag = CheckToMove(field,nextBlock[0],blockRotate,blockY,blockX-1)))
			blockX--;
		break;
	default:
		break;
	}
	if(drawFlag) DrawChange(field,command,nextBlock[0],blockRotate,blockY,blockX);
	return ret;
}

void DrawField(){
	int i,j;
	for(j=0;j<HEIGHT;j++){
		move(j+1,1);
		for(i=0;i<WIDTH;i++){
			if(field[j][i]==1){
				attron(A_REVERSE);
				printw(" ");
				attroff(A_REVERSE);
			}
			else printw(".");
		}
	}
}


void PrintScore(int score){
	move(18,WIDTH+11); // nextblock을 두 개를 보여줌에 따라 위치를 수정했다.ㅑ
	printw("%8d",score);
}

void DrawNextBlock(int *nextBlock){
	int i, j;
	for( i = 0; i < 4; i++ ){
		move(4+i,WIDTH+13);
		for( j = 0; j < 4; j++ ){
			if( block[nextBlock[1]][0][i][j] == 1 ){
				attron(A_REVERSE);
				printw(" ");
				attroff(A_REVERSE);
			}
			else printw(" ");
		}
	}
	for(i=0; i<4; i++) //다다음 블록
	{
		move(10+i,WIDTH+13);
		for(j=0; j<4; j++)
		{
			if(block[nextBlock[2]][0][i][j]==1)
			{
				attron(A_REVERSE);
				printw(" ");
				attroff(A_REVERSE);
			}
			else printw(" ");
		}
	}
}

void DrawBlock(int y, int x, int blockID,int blockRotate,char tile){
	int i,j;
	for(i=0;i<4;i++)
		for(j=0;j<4;j++){
			if(block[blockID][blockRotate][i][j]==1 && i+y>=0){
				move(i+y+1,j+x+1);
				attron(A_REVERSE);
				printw("%c",tile);
				attroff(A_REVERSE);
			}
		}
	move(HEIGHT,WIDTH+10);
}

void DrawBox(int y,int x, int height, int width){
	int i,j;
	move(y,x);
	addch(ACS_ULCORNER);
	for(i=0;i<width;i++)
		addch(ACS_HLINE);
	addch(ACS_URCORNER);
	for(j=0;j<height;j++){
		move(y+j+1,x);
		addch(ACS_VLINE);
		move(y+j+1,x+width+1);
		addch(ACS_VLINE);
	}
	move(y+j+1,x);
	addch(ACS_LLCORNER);
	for(i=0;i<width;i++)
		addch(ACS_HLINE);
	addch(ACS_LRCORNER);
}

void play(){
	int command;
	clear();
	act.sa_handler = BlockDown;
	sigaction(SIGALRM,&act,&oact);
	InitTetris();
	do{
		if(timed_out==0){
			alarm(1);
			timed_out=1;
		}

		command = GetCommand();
		if(ProcessCommand(command)==QUIT){
			alarm(0);
			DrawBox(HEIGHT/2-1,WIDTH/2-5,1,10);
			move(HEIGHT/2,WIDTH/2-4);
			printw("Good-bye!!");
			refresh();
			getch();

			return;
		}
	}while(!gameOver);

	alarm(0);
	getch();
	DrawBox(HEIGHT/2-1,WIDTH/2-5,1,10);
	move(HEIGHT/2,WIDTH/2-4);
	printw("GameOver!!");
	refresh();
	getch();
	newRank(score);
}

char menu(){
	printw("1. play\n");
	printw("2. rank\n");
	printw("3. recommended play\n");
	printw("4. exit\n");
	return wgetch(stdscr);
}

/////////////////////////첫주차 실습에서 구현해야 할 함수/////////////////////////

int CheckToMove(char f[HEIGHT][WIDTH],int currentBlock,int blockRotate, int blockY, int blockX){
	// user code
	int i,j;
	for(i=0; i<BLOCK_HEIGHT; i++)
	{
		for(j=0; j<BLOCK_WIDTH; j++)
		{
			if(block[currentBlock][blockRotate][i][j]==1)
			{
				if(f[i+blockY][j+blockX]==1) return 0; //이미 블록이 있는 경우
				if(i+blockY>=HEIGHT || j+blockX<0 || j+blockX>=WIDTH) return 0; //y좌표가 HEIGHT를 넘어가거나 x좌표가 0보다 작거나 WIDTH를 넘어가는 경우
			}
		}
	}
	return 1;//전부 아닐 경우 가능하므로 1 리턴
}

void DrawChange(char f[HEIGHT][WIDTH],int command,int currentBlock,int blockRotate, int blockY, int blockX){
	// user code
	int i,j;
	int before_rotate=blockRotate; //회전 변수
	int before_blockY=blockY; //y좌표
	int before_blockX=blockX; //x좌표

	switch(command) //블록 상태 변경
	{
		case KEY_UP: //다시 반대로 회전해야한다.
			before_rotate--; //회전
			if(before_rotate==-1) before_rotate=3; // -1이라는 회전 상태는 없으므로 3으로 바꿔준다.
			break;
		case KEY_DOWN: // 1칸 아래로 갔으니 아까는 위쪽에 있다.
			before_blockY--;
			break;
		case KEY_LEFT: //1칸 왼쪽으로 갔으니 아까는 오른쪽에 있다.
			before_blockX++;
			break;
		case KEY_RIGHT: //1칸 오른쪽으로 갔으니 아까는 왼쪽에 있다.
			before_blockX--;
			break;
	}
	DrawBlock(before_blockY, before_blockX , currentBlock, before_rotate, '.'); // 이전 블록을 전부 지운다. ('.'으로 바꿈으로써 빈 칸이 된다.)
	DrawField(); // 보드를 새로 그린다.
	//DrawBlock(blockY, blockX, currentBlock, blockRotate, ' '); //새 블록을 그린다. (' '으로 바꿈으로써 블록이 된다.)  ==> 6주차과제에서 DrawBlockWithFeatures로 대체됨.
	DrawBlockWithFeatures(blockY,blockX,currentBlock,blockRotate); // 그림자도 그리기 위해 대체된 함수 호출


	//1. 이전 블록 정보를 찾는다. ProcessCommand의 switch문을 참조할 것
	//2. 이전 블록 정보를 지운다. DrawBlock함수 참조할 것.
	//3. 새로운 블록 정보를 그린다.
}

void BlockDown(int sig){
	// user code
	int i,j;//9주차 추가
	if(CheckToMove(field, nextBlock[0], blockRotate, blockY+1, blockX)==1) // 자동으로 내려갈 위치에 내려갈 수 있는지를 판단한다. 1이면 가능
	{
		blockY++;
		DrawChange(field, KEY_DOWN, nextBlock[0], blockRotate, blockY, blockX); // 아래로 내려가니까 command는 KEY_DOWN
	}

	else //못 내려가면
	{
		if(blockY==-1) gameOver=1; //맨 위에 도달하면 게임 끝!
		score+=AddBlockToField(field, nextBlock[0], blockRotate, blockY, blockX); //내려간 장소에 블록을 채운다.
		score+=DeleteLine(field); //점수 계산, 꽉 찬 줄이 있으면 점수를 더한다.
		nextBlock[0]=nextBlock[1]; // 현재 블록이 다음걸로 예정되어 있던 블록으로 바뀐다.
		nextBlock[1]=nextBlock[2];
		nextBlock[2]=nextBlock[3];
		nextBlock[3]=rand()%7; //다음 블록을 랜덤으로 설정해준다.

		recRoot->lv=0;
		recRoot->score=0;
		for(i=0; i<HEIGHT; i++)
		{
			for(j=0; j<WIDTH; j++)
			{
				recRoot->f[i][j]=field[i][j];
			}
		}
		modified_recommend(recRoot); //9주차 추가, 추천 시스템을 위한 초기화 과정.
		if(recommendY==-1) gameOver=1;
		blockY=-1; //위치 초기화
		blockX=(WIDTH/2)-2; //위치 초기화
		DrawNextBlock(nextBlock); //다음 블록이 뭔지 보여준다.
		PrintScore(score); //스코어 갱신!
		DrawField(); //판을 새로 출력한다.
	}
	timed_out=0; //시간 초기화
	//강의자료 p26-27의 플로우차트를 참고한다.
}

int AddBlockToField(char f[HEIGHT][WIDTH],int currentBlock,int blockRotate, int blockY, int blockX){
	// user code
	int i,j;
	int touched=0; // 바닥 블록 개수
	for(i=0; i<BLOCK_HEIGHT; i++)
	{
		for(j=0; j<BLOCK_WIDTH; j++)
		{
			if(block[currentBlock][blockRotate][i][j]==1) // 4x4 중에 블록이 존재하는 위치이면
			{
				if(blockY+i+1>=HEIGHT) // 한 칸 아래에  바닥이 있는 경우
				{
					touched++;
				}
				else if(f[i+blockY+1][j+blockX]==1) //아니면 한 칸 아래에  원래 있던 블록 이 있는  경우
				{
					touched++;
				}
				f[i+blockY][j+blockX]=1; // 블록으로 바꾼다.
			}
		}
	}
	return touched*10;
	//Block이 추가된 영역의 필드값을 바꾼다.
}

int DeleteLine(char f[HEIGHT][WIDTH]){
	// user code
	int i,j,k;
	int line=0; //사라질 라인의 개수
	for(i=0; i<HEIGHT; i++)
	{
		for(j=0; j<WIDTH; j++)
		{
			if(f[i][j]==0) break; // 줄에 빈칸이 하나라도 있으면 점수 계산에서 제외되므로
		}
		if(j==WIDTH) //그 라인이 전부 블록으로 채워졌다는 의미이다. for문을 break로 벗어나지 않았다는 뜻.
		{
			line++; //꽉 찬 라인의 개수 하나 추가
			for(j=0; j<WIDTH; j++)
			{
				f[i][j]=0; //빈공간으로 바꿔준다.
			}
			for(k=i; k>0; k--) // 판을 전부 한 칸 아래로 보낸다.
			{
				for(j=0; j<WIDTH; j++)
				{
					f[k][j]=f[k-1][j]; //한칸 아래로 이동해야 하므로
					f[k-1][j]=0; //원래 자리는 빈칸으로 바꿔준다.
				}
			}
		}
	}
	return line*line*100;


	//1. 필드를 탐색하여, 꽉 찬 구간이 있는지 탐색한다.
	//2. 꽉 찬 구간이 있으면 해당 구간을 지운다. 즉, 해당 구간으로 필드값을 한칸씩 내린다.
}

///////////////////////////////////////////////////////////////////////////

void DrawShadow(int y, int x, int blockID,int blockRotate){
	// user code
	int downy=y;
	while(CheckToMove(field,blockID,blockRotate,downy,x)==1) // 이동이 안 될 때까지 아래로 내려가본다.
	{
		downy++;
	}
	downy--; //이동이 안 되는 지점에 도달했으니 그보다 한 칸 위로 가야 정상적인 하강임.
	DrawBlock(downy,x,blockID,blockRotate,'/'); // 그 좌표를 보내준다.
}

void DrawBlockWithFeatures(int y, int x, int blockID, int blockRotate)
{
	DrawShadow(y,x,blockID,blockRotate); //그림자를 그려준다
	DrawBlock(y,x,blockID,blockRotate,' '); // 나머지 공간은 빈 공간이겠지?
	DrawRecommend(recommendY, recommendX, blockID, recommendR);//9주차 추가, 추천 그려줌
}

void createRankList(){
	// user code
	FILE *fp;
	int i,j;
	rankcount=0;
	if((fp=fopen("rank.txt","r"))==NULL) return;
	fscanf(fp,"%d",&rankcount); //랭킹 사람 수를 입력

	Node *ranking;
	Node *tmp; 
	for(i=1; i<=rankcount; i++)
	{
		printf("i:%d\n",i);
		ranking=(Node*)malloc(sizeof(Node)); //할당
		fscanf(fp,"%s %d",ranking->name,&(ranking->score)); //랭킹 정보 입력
		if(head==NULL) //맨 처음이면 노드 할당해주고 시작 (head 포인터 생성)
		{
			head=ranking;
			tmp=head;
		}
		else //첫 사람이 아니면 다음 사람으로 가야함
		{
			tmp->link=ranking;
			tmp=tmp->link;
		}
	}
	fclose(fp);
}

void rank(){
	// user code
	clear(); // 화면 깨끗하게
	int x=1, y=rankcount, mode;
	int cnt=0;
	printw("1. list ranks from X to Y\n");   
	printw("2. list ranks by a specific name\n");
	printw("3. delete a specific rank\n");
	mode=wgetch(stdscr);
	//여기까지 rank 모드의 입력과정
	if(mode=='1')
	{
		printw("X: ");
		echo();
		scanw("%d",&x);
		printw("Y: ");
		scanw("%d",&y);
		noecho();
		printw("     name       |     score     \n");
		printw("------------------------------\n");
		if(x>y || rankcount==0 || x>rankcount) //x>y 이거나 저장된 랭킹이 없거나 x가 총 등록 수보다 크면
		{
			mvprintw(8, 0, "search failure: no rank in the list\n"); // 에러 메시지 출력
		}
		else
		{
			Node *tmp=head;
			int i=1;
			while(tmp!=NULL) //끝나기 전까지 리스트 확인
			{
				if(i>=x && i<=y) // x<=i<=y이면
				{
					printw(" %-14s | %-10d\n",tmp->name,tmp->score); // 스코어 출력
				}
				i++; //등수 하나 증가	
				tmp=tmp->link; //다음 노드로
			}
		}
	}
	if(mode=='2')
	{
		int count=0;
		char name[NAMELEN+1];
		printw("Input the name: "); //이름 입력
		echo();
		scanw("%s",name);
		noecho();
		printw("     name       |     score     \n");
		printw("------------------------------\n");
		Node *ranking=(Node*)malloc(sizeof(Node)); //처음부터 찾아보자
		ranking=head;
		while(ranking!=NULL)
		{
			if(!strcmp(ranking->name,name)) //같은 이름을 찾으면
			{
				printw(" %-14s | %-10d\n",ranking->name,ranking->score); //출력
				count++; //카운트 더해줌
			}
			ranking=ranking->link;
		}
		if(count==0) printw("search failure: no name in the list\n"); //아무도 없으면 에러 출력
	}
	if(mode=='3')
	{
		int x, count=1;
		printw("Input the rank: ");
		echo();
		scanw("%d",&x);
		noecho();
		Node *ranking=(Node*)malloc(sizeof(Node));
		Node *prev=(Node*)malloc(sizeof(Node));
		ranking=head;
		if(x>rankcount || x<1) printw("search failure: the rank not in the list");
		else
		{
			while(count!=x)
			{
				prev=ranking;
				ranking=ranking->link;
				count++;
			}
			prev->link=ranking->link;
			rankcount--;
			free(ranking);
			writeRankFile();
			printw("result: the rank deleted\n");
		}
	}
	getch();
}

void writeRankFile(){
	// user code
	FILE *fp;
	int i;
	fp=fopen("rank.txt","w");
	fprintf(fp, "%d\n",rankcount);
	Node *tmp=head; //head부터 시작
	for(i=0; i<rankcount; i++) //등록 된 숫자 만큼 작성
	{
		fprintf(fp,"%s %d\n",tmp->name,tmp->score); //랭킹 등록
		tmp=tmp->link; //다음 노드로
	}
	fclose(fp);
}

void newRank(int score){
	// user code
	char name[NAMELEN+1];
	int i,j;
  
	clear(); // 화면 초기화
	printw("your name: ");
	echo();
	scanw("%s",name);
	noecho();
	Node *newrank;
	newrank=(Node*)malloc(sizeof(Node));
	newrank->link=NULL;
	newrank->score=score;
	strcpy(newrank->name,name);  //여기까지 newrank에 사용자 정보 입력

	Node *tmp=head; //시작부터 찾는다. 
	Node *left; // 랭킹을 새로 삽입하면 왼쪽 노드랑도 연결이 유지되어야 하므로 필요하다.
	if(tmp==NULL) // 랭킹이 비어있다는 소리. 즉 첫 랭킹 사용자
	{
		head=newrank;
	}
	else
	{
		while(tmp!=NULL)
		{
			if(tmp->score < score)
			{
				if(tmp==head) //1등이면
				{
					newrank->link=head;
					head=newrank;
					break; //맨 앞에 저장해준다.
				}
				else // 아니면
				{
					newrank->link=tmp; //새 랭크의 다음 노드가 tmp가 됨
					left->link=newrank; // newrank 왼쪽 노드가 newrank가 됨.
					break;
				}
			} 
			left=tmp;  
			tmp=tmp->link;  //다음 노드 탐색
		}
	}
	left->link=newrank;
	rankcount++; //랭킹 등록된 숫자 하나 증가
	writeRankFile();
}

void DrawRecommend(int y, int x, int blockID,int blockRotate){
	DrawBlock(y,x,blockID,blockRotate,'R');
}

int space; //공간 복잡도 계산용

int recommend(RecNode *root){
	int max=0; // 미리 보이는 블럭의 추천 배치까지 고려했을 때 얻을 수 있는 최대 점수

	// user code
	int sx,ex,x,y,r;
	int N=0,i,j;
	recommendX=0; recommendY=0; recommendR=0;
	RecNode *tmp; // root의 child가 될 예정
	RecNode *fr; //free용도
	space=0;
	for(r=0; r<4; r++)
	{
		sx=WIDTH/2-3;
		ex=WIDTH/2-1;
		while(CheckToMove(root->f, nextBlock[root->lv], r, 0, sx))
		{
			sx--;
		}
		sx++; // 시작 x좌표를 찾는다.
		while(CheckToMove(root->f, nextBlock[root->lv], r, 0, ex))
		{
			ex++;
		}
		ex--; //끝 x좌표를 찾는다.
		for(x=sx; x<=ex; x++)
		{
			space++; //노드 개수마다 1 증가
			y=3;
			while(CheckToMove(root->f, nextBlock[root->lv], r, y, x))
			{
				y++;
			}
			y--;
			tmp=(RecNode*)malloc(sizeof(RecNode));
			tmp->score=root->score;
			tmp->lv=root->lv+1;
			tmp->rbr=r;
			tmp->ry=y;
			tmp->rx=x;
			for(i=0; i<HEIGHT; i++)
			{
				for(j=0; j<WIDTH; j++)
				{
					tmp->f[i][j]=root->f[i][j];
				}
			}
			tmp->score+=AddBlockToField(tmp->f, nextBlock[root->lv], r, y, x);
			tmp->score+=DeleteLine(tmp->f); //스코어 정산
			root->c[N]=tmp; //tmp의 부모가 root가 되는 순간
			if(tmp->lv<VISIBLE_BLOCKS) tmp->score=recommend(tmp); //아직 모든 깊이를 확인하지 않았으니 재귀적으로 호출해준다!
			if(tmp->score>max) max=tmp->score; //최댓값 갱신
			N++; //경우 하나 증가
		}
	}
	if(root->lv==0) //레벨이 0이면
	{
		for(i=0; i<N; i++)
		{
			if(root->c[i]->score==max)
			{
				recommendX=root->c[i]->rx;
				recommendY=root->c[i]->ry;
				recommendR=root->c[i]->rbr;
			}
			fr=root->c[i];
			free(fr);
		}
	}
	else																								
	{
		for(i=0; i<N; i++)
		{
			fr=root->c[i];
			free(fr);
		}
	}//지금까지 노드 할당 해제해주는 코드
	return max;
}

int modified_recommend(RecNode *root){
	int max=0; // 미리 보이는 블럭의 추천 배치까지 고려했을 때 얻을 수 있는 최대 점수

	// user code
	int sx,ex,x,y,r;
	int N=0,i,j,cnt=nextBlock[root->lv];
	recommendX=0; recommendY=0; recommendR=0;
	RecNode *tmp; // root의 child가 될 예정
	RecNode *fr; //free용도
	space=0;
	if(cnt==4) cnt=1;
	else if(cnt==0 || cnt==5 || cnt==6) cnt=2;
	else cnt=4; //회전 횟수를 줄여준다.
	for(r=0; r<cnt; r++)
	{
		sx=WIDTH/2-3;
		ex=WIDTH/2-1;
		while(CheckToMove(root->f, nextBlock[root->lv], r, 0, sx))
		{
			sx--;
		}
		sx++; // 시작 x좌표를 찾는다.
		while(CheckToMove(root->f, nextBlock[root->lv], r, 0, ex))
		{
			ex++;
		}
		ex--; //끝 x좌표를 찾는다.
		for(x=sx; x<=ex; x++)
		{
			space++; //노드 개수마다 1 증가
			y=3;
			while(CheckToMove(root->f, nextBlock[root->lv], r, y, x))
			{
				y++;
			}
			y--;
			tmp=(RecNode*)malloc(sizeof(RecNode));
			tmp->score=root->score;
			tmp->lv=root->lv+1;
			tmp->rbr=r;
			tmp->ry=y;
			tmp->rx=x;
			for(i=0; i<HEIGHT; i++)
			{
				for(j=0; j<WIDTH; j++)
				{
					tmp->f[i][j]=root->f[i][j];
				}
			}
			tmp->score+=AddBlockToField(tmp->f, nextBlock[root->lv], r, y, x);
			tmp->score+=DeleteLine(tmp->f); //스코어 정산
			tmp->score+=y*7-tmp->lv;
			root->c[N]=tmp; //tmp의 부모가 root가 되는 순간
			if(tmp->lv<VISIBLE_BLOCKS) tmp->score=modified_recommend(tmp); //아직 모든 깊이를 확인하지 않았으니 재귀적으로 호출해준다!
			if(tmp->score>max) max=tmp->score; //최댓값 갱신
			N++; //경우 하나 증가
		}
	}
	if(root->lv==0) //레벨이 0이면
	{
		for(i=0; i<N; i++)
		{
			if(root->c[i]->score==max)
			{
				recommendX=root->c[i]->rx;
				recommendY=root->c[i]->ry;
				recommendR=root->c[i]->rbr;
			}
			fr=root->c[i];
			free(fr);
		}
	}
	else																								
	{
		for(i=0; i<N; i++)
		{
			fr=root->c[i];
			free(fr);
		}
	}
	return max;
}

void recommendedPlay(){
	// user code
	int stime,ftime; //시작한 시간
	int command;
	clear();
	act.sa_handler=BlockDown;
	sigaction(SIGALRM,&act,&oact);
	InitTetris();
	stime=time(NULL);
	do
	{
		if(timed_out==0)
		{
			ualarm(1000,1000);
			timed_out=1;
		
			blockY=recommendY;
			blockX=recommendX;
			blockRotate=recommendR; //추천 위치로만 이동해야 하므로 설정해준다.
			ftime=time(NULL);
			mvprintw(28,1,"score(t)=%d, time(t)=%d, space(t)=%d",score,ftime-stime,space); //score,time 계산
			mvprintw(29,1,"time_efficiency(t)=%.3lf, space_efficiency(t)=%.3lf",(double)score/(ftime-stime),(double)score/space); //효율성 계산
		}
		command=GetCommand(); //이하 기본 템플릿이랑 동일
		if(ProcessCommand(command)==QUIT)
		{
			alarm(0);
			DrawBox(HEIGHT/2-1,WIDTH/2-5,1,10);
			move(HEIGHT/2,WIDTH/2-4);
			printw("Good-Bye!!");
			refresh();
			getch();
			return;
		}
	}while(!gameOver);
	alarm(0);
	getch();
	DrawBox(HEIGHT/2-1,WIDTH/2-5,1,10);
	move(HEIGHT/2,WIDTH/2-4);
	printw("GameOver!!");
	refresh();
	getch();
	if(gameOver==1)
	{
		newRank(score);
	}		
}
