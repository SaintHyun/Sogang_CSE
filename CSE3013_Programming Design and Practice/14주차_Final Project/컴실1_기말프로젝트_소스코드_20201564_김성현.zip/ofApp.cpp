#include "ofApp.h"
#include <fstream>
using namespace std;
//--------------------------------------------------------------
void ofApp::setup(){
	ofSetWindowTitle("Navigation");
	ofSetFrameRate(15);
	ofBackground(255, 255, 255);
	windowWidth = ofGetWidth();
	windowHeight = ofGetHeight();
	ofSetWindowPosition((ofGetScreenWidth() - windowWidth) / 2, (ofGetScreenHeight() - windowHeight) / 2);
	myFont.loadFont("verdana.ttf", 12, true, true);
	hWnd = WindowFromDC(wglGetCurrentDC());
	ofSetEscapeQuitsApp(false);
	menu = new ofxWinMenu(this, hWnd);
	menu->CreateMenuFunction(&ofApp::appMenuFunction);
	HMENU hMenu = menu->CreateWindowMenu();
	HMENU hPopup = menu->AddPopupMenu(hMenu, "File");
	menu->AddPopupItem(hPopup, "Open", false, false); // Not checked and not auto-checked
	menu->AddPopupSeparator(hPopup);
	menu->AddPopupItem(hPopup, "Exit", false, false);
	hPopup = menu->AddPopupMenu(hMenu, "View");
	bShowInfo = true;  // screen info display on
	menu->AddPopupItem(hPopup, "Show Result", false, false); // Checked
	bTopmost = false; // app is topmost
	bFullscreen = false; // not fullscreen yet
	menu->AddPopupItem(hPopup, "Full screen", false, false); // Not checked and not auto-check
	menu->SetWindowMenu();

}

void ofApp::appMenuFunction(string title, bool bChecked) {

	ofFileDialogResult result;
	string filePath;
	size_t pos;

	//
	// File menu
	//
	if (title == "Open") {
		readFile();

	}
	if (title == "Show Result")
	{
		daik = 1;
		daijkstra(start, stop);
		printpath();
	}
	if (title == "Exit") {
		ofExit(); // Quit the application
	}

	if (title == "Full screen") {
		bFullscreen = !bFullscreen; // Not auto-checked and also used in the keyPressed function
		doFullScreen(bFullscreen); // But als take action immediately
	}

} 

//--------------------------------------------------------------
void ofApp::update(){

}

//--------------------------------------------------------------
void ofApp::draw(){
	if (isdraw)
	{
		int i, j;
		{
		city[1].y = 56.375750; city[1].x = 85.473860;
		city[2].y = 63.054000; city[2].x = 85.515710;
		city[3].y = 85.850000; city[3].x = 89.425580;
		city[4].y = 109.365000; city[4].x = 94.267000;
		city[5].y = 124.570000; city[5].x = 120.715000;
		city[6].y = 127.455000; city[6].x = 121.924000;
		city[7].y = 141.712500; city[7].x = 120.538300;
		city[8].y = 141.100000; city[8].x = 127.567000;
		city[9].y = 162.975000; city[9].x = 214.579000;
		city[10].y = 187.155000; city[10].x = 243.280000;
		city[11].y = 185.350000; city[11].x = 258.545000;
		city[12].y = 187.805000; city[12].x = 261.966000;
		city[13].y = 216.080000; city[13].x = 310.438000;
		city[14].y = 241.632500; city[14].x = 307.816720;
		city[15].y = 267.201000; city[15].x = 133.820310;
		city[16].y = 254.148250; city[16].x = 195.902300;
		city[17].y = 241.257500; city[17].x = 241.676760;
		city[18].y = 246.745000; city[18].x = 289.508610;
		city[19].y = 246.501500; city[19].x = 69.619320;
		city[20].y = 230.418750; city[20].x = 108.123360;
		city[21].y = 218.941750; city[21].x = 159.472620;
		city[22].y = 199.128250; city[22].x = 226.358130;
		city[23].y = 56.065750; city[23].x = 59.461020;
		city[24].y = 83.993750; city[24].x = 61.628150;
		city[25].y = 278.603750; city[25].x = 16.991000;
		city[26].y = 217.010500; city[26].x = 323.294380;
		city[27].y = 178.875000; city[27].x = 342.622000;
		city[28].y = 170.312000; city[28].x = 85.394500;
		city[29].y = 244.050250; city[29].x = 52.712330;
		city[30].y = 41.569000; city[30].x = 95.806690;
		city[31].y = 55.770000; city[31].x = 109.503400;
		city[32].y = 67.857750; city[32].x = 121.381190;
		city[33].y = 94.056500; city[33].x = 126.499360;
		city[34].y = 152.545250; city[34].x = 123.813680;
		city[35].y = 278.245500; city[35].x = 234.146870;
		city[36].y = 85.257750; city[36].x = 156.037670;
		city[37].y = 81.679500; city[37].x = 204.519280;
		city[38].y = 68.196250; city[38].x = 139.520970;
		city[39].y = 145.069000; city[39].x = 211.560610;
		city[40].y = 58.240750; city[40].x = 58.504440;
		city[41].y = 56.381750; city[41].x = 174.166290;
		city[42].y = 54.422500; city[42].x = 177.383700;
		city[43].y = 20.194250; city[43].x = 277.676080;
		city[44].y = 139.175000; city[44].x = 253.998700;
		city[45].y = 22.143000; city[45].x = 161.427090;
		city[46].y = 14.014250; city[46].x = 159.107210;
		city[47].y = 37.918250; city[47].x = 92.347560;
		city[48].y = 21.447500; city[48].x = 181.185070;
		city[49].y = 151.487000; city[49].x = 109.087770;
		city[50].y = 143.417500; city[50].x = 337.140200;
		city[51].y = 42.475000; city[51].x = 123.628300;
		city[52].y = 50.357250; city[52].x = 44.974430;
		} 
		// �б��� ��ǥ�� �Է�. �ſ� �� �������

		ofSetColor(127, 23, 31); //������ ��������
		for (i = 1; i <= 52; i++) //�ϳ� �ϳ� �׷��ش�.
		{
			ofDrawCircle(city[i].x * 3, city[i].y * 3, 5);
		}
		ofSetColor(100); //���δ� ȸ������
		ofSetLineWidth(2);
		for (i = 1; i <= 67; i++) //�ϳ� �ϳ� �׷��ش�.
		{
			for (j = 1; j <= 67; j++)
			{
				if (data.way[i][j] != 9876543)
				{
					ofDrawLine(city[i].x * 3, city[i].y * 3, city[j].x * 3, city[j].y * 3);
				}
			}
		}
	}
	int i;
	if (drawpath) // Show Result ������
	{
		ofSetLineWidth(4);
		ofSetColor(255, 0, 0); 
		ofDrawCircle(city[stop].x * 3, city[stop].y * 3, 4);
		for (i = f; i >= 0; i--)
		{
			ofSetColor(255, 0, 0); //�湮�� ������ ����������
			ofDrawCircle(city[path[i]].x * 3, city[path[i]].y * 3, 4);
			ofSetColor(0, 255, 0); //�湮�� ��δ� �ʷϻ�����
			if (i != f) ofDrawLine(city[path[i]].x * 3, city[path[i]].y * 3, city[path[i + 1]].x * 3, city[path[i + 1]].y * 3);
		}
	}
}

void ofApp::doFullScreen(bool bFull)
{
	// Enter full screen
	if (bFull) {
		// Remove the menu but don't destroy it
		menu->RemoveWindowMenu();
		// hide the cursor
		ofHideCursor();
		// Set full screen
		ofSetFullscreen(true);
	}
	else {
		// return from full screen
		ofSetFullscreen(false);
		// Restore the menu
		menu->SetWindowMenu();
		// Restore the window size allowing for the menu
		ofSetWindowShape(windowWidth, windowHeight + GetSystemMetrics(SM_CYMENU));
		// Centre on the screen
		ofSetWindowPosition((ofGetScreenWidth() - ofGetWidth()) / 2, (ofGetScreenHeight() - ofGetHeight()) / 2);
		// Show the cursor again
		ofShowCursor();
		// Restore topmost state
		if (bTopmost) doTopmost(true);
	}

} 

void ofApp::doTopmost(bool bTop)
{
	if (bTop) {
		// get the current top window for return
		hWndForeground = GetForegroundWindow();
		// Set this window topmost
		SetWindowPos(hWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
		ShowWindow(hWnd, SW_SHOW);
	}
	else {
		SetWindowPos(hWnd, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
		ShowWindow(hWnd, SW_SHOW);
		// Reset the window that was topmost before
		if (GetWindowLong(hWndForeground, GWL_EXSTYLE) & WS_EX_TOPMOST)
			SetWindowPos(hWndForeground, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
		else
			SetWindowPos(hWndForeground, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
	}
} // end doTopmost


//--------------------------------------------------------------
void ofApp::keyPressed(int key){
	// Escape key exit has been disabled but it can be checked here
	if (key == VK_ESCAPE) {
		// Disable fullscreen set, otherwise quit the application as usual
		if (bFullscreen) {
			bFullscreen = false;
			doFullScreen(false);
		}
		else {
			ofExit();
		}
	}

	// Remove or show screen info
	if (key == ' ') {
		bShowInfo = !bShowInfo;
		// Update the menu check mark because the item state has been changed here
		menu->SetPopupItem("Show DFS", bShowInfo);
	}

	if (key == 'f') {
		bFullscreen = !bFullscreen;
		doFullScreen(bFullscreen);
		// Do not check this menu item
		// If there is no menu when you call the SetPopupItem function it will crash
	}
}

bool ofApp::readFile()
{
	ofFileDialogResult openFileResult = ofSystemLoadDialog("Select .txt file");
	string filePath;
	size_t pos;
	int i, j;
	// Check whether the user opened a file
	if (openFileResult.bSuccess) {
		ofLogVerbose("User selected a file");

		//We have a file, check it and process it
		string fileName = openFileResult.getName();
		//string fileName = "maze0.maz";
		printf("file name is %s\n", fileName.c_str());
		//cout << "file name is " << fileName << endl;
		filePath = openFileResult.getPath();
		printf("Open\n");
		pos = filePath.find_last_of(".");
		if (pos != string::npos && pos != 0 && filePath.substr(pos + 1) == "txt") {

			ofFile file(fileName);

			if (!file.exists()) {
				cout << "Target file does not exists." << endl;
				return false;
			}
			else {
				cout << "We found the target file." << endl;
				isOpen = 1;
			}
			file >> n; file >> m;
			for (i = 1; i <= 100; i++)
			{
				for (j = 1; j <= 100; j++)
				{
					data.way[i][j] = 9876543;
					data.time[i][j] = 9876543;
				}
			}
			int a, b;
			double c, e, maxtra, tra; //���� ��ķ� ǥ���ϱ� ���� �ӽ� ����
			for (i = 1; i <= m; i++)
			{
				file >> a; file >> b; file >> c; file >> e; file >> maxtra; file >> tra;
				data.way[a][b] = c; //����� ����
				data.way[b][a] = c;
				data.time[a][b] = e; //��� �ҿ� �ð�
				data.time[b][a] = e;
				data.traffic[a][b] = tra; //����� ���� Ʈ����
				data.traffic[b][a] = tra;
				data.maxtraffic[a][b] = maxtra; //����� �ִ� Ʈ����
				data.maxtraffic[b][a] = maxtra; //�Է°� ����
			}
			file >> start; file >> stop; //����, �����
			file >> x; file >> y; //����ġ
			isdraw = 1;
			draw();
		}
		else {
			printf("  Needs a '.txt' extension\n");
			return false;
		}
	}
	
}

void ofApp::daijkstra(int go, int fin) // ���ͽ�Ʈ�� �˰����� Ȱ��
{
	double min;
	int cur, i, j;
	for (i = 1; i < 1000; i++)
	{
		totdis[i] = 9876543.0;
		tottime[i] = 9876543.0;
		p[i] = 0;
		check[i] = 0;
	} //�ʱ�ȭ
	totdis[start] = 0;
	tottime[start] = 0; //���� ���� 0����
	for (i = 1; i <= m; i++) //��� ��θ� �ѷ�����.
	{
		min = 987654321; //min �ʱ�ȭ
		for (j = 1; j <= m; j++) //��� ��θ� �ѷ�����.
		{
			if (check[j] == 0 && totdis[j] * x + tottime[j] * y < min) //�湮 x && �ּڰ� ����
			{
				cur = j; //���� ��ġ ����
				min = totdis[j] * x + tottime[j] * y;
			}
		}
		check[cur] = 1; //���� ��ġ�� �湮����
		for (j = 1; j <= m; j++)
		{
			if (data.traffic[cur][j] > data.maxtraffic[cur][j]) // ���뷮�� �ִ� ���뷮���� ���� ���
			{
				if (totdis[j] * x + tottime[j] * y > (totdis[cur] + data.way[cur][j]) * x + (tottime[cur] + data.time[cur][j]) * y + (data.traffic[cur][j] - data.maxtraffic[cur][j]) * 0.005 / 10 * y)
				{
					totdis[j] = totdis[cur] + data.way[cur][j];
					tottime[j] = tottime[cur] + data.time[cur][j] + (data.traffic[cur][j] - data.maxtraffic[cur][j]) * 0.005 / 10;
					p[j] = cur;
				}
			}
			if (data.traffic[cur][j] <= data.maxtraffic[cur][j]) // ���뷮�� �γ��� ���
			{
				if (totdis[j] * x + tottime[j] * y > (totdis[cur] + data.way[cur][j]) * x + (tottime[cur] + data.time[cur][j]) * y)
				{
					totdis[j] = totdis[cur] + data.way[cur][j];
					tottime[j] = tottime[cur] + data.time[cur][j];
					p[j] = cur;
				}
			}

		}
		if (cur == fin) break; //���� �����̸� ��
	}
}

void ofApp::printpath()
{
	int i, j = 0, t, pre;
	for (i = 1; i <= m; i++)
	{
		pre = i;
		t = 0;
		if (pre == stop) j = 1; //���� ������ ���� ��� ���
		if (pre != start)
		{
			if (check[i] > 0)
			{
				do
				{
					path[t++] = pre;
					pre = p[pre];
				} while (pre != start);
				path[t] = pre;
				if (j)
				{
					f = t;
					while (t >= 0)
					{
						printf("%d", path[t]);
						if (t-- != 0)
						{
							printf("-->");
						}
					}
					printf("\n");
					j = 0;
					break;
				}
			}

		}
	}
	printf("\n%d => %d : distance %lf, time %lf\n", start, stop, totdis[stop], tottime[stop]);
	drawpath = 1;
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
