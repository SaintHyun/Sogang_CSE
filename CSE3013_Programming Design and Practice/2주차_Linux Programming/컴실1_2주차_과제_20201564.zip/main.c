#include "Header.h"  //헤더파일선언

int scan();  //입력함수
void solution(int n); //구하고자 하는 것을 구해준다.

int main()
{
	int i;
	int t;
	int n;
	t=scan(); //테스트케이스 입력 
	for(i=1; i<=t; i++)
	{
		n=scan();  //숫자 입력
		solution(n); //입력된 숫자에 대한 답을 구해내는 함수 호출
	}
	return 0;
}




