#include "Header.h"

void solution(int n)
{
	int a[100]={0,},i,j;
	for(j=1; j<=n; j++) //1부터 n까지 하나씩 다 돌아본다.
	{
		i=j; 
		while(i>0)
		{
			a[i%10]+=1;			//일의 자리 숫자에 해당하는 값을 하나 늘린다.
			i/=10;  //숫자를 10으로 나눈다.
		}   //이로써 1부터 n까지 0~9가 몇 번 씩 나왔는지 세어진다.

	}
	for(i=0; i<10; i++) //출력
	{
		printf("%d ",a[i]);
		a[i]=0;
	}
	printf("\n");
}

