#include "Header.h"

int scan()
{
	int a; 
	scanf("%d",&a); //입력 후 리턴
	return a;
}
