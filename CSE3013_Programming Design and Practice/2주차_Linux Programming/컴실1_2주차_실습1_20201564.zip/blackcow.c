#include<stdio.h>

void blackcow()
{
	printf("Moo\n");
}

