#include<stdio.h>

void dog()
{
	printf("Bow Wow\n");
}

