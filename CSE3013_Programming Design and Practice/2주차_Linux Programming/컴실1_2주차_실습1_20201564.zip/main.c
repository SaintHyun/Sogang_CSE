#include<stdio.h>

int main()
{
	dog();
	blackcow();
	turtle();
}
