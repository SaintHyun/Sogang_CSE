#include "ofApp.h"
#include <iostream>
using namespace std;
//--------------------------------------------------------------
void ofApp::setup() {

	ofSetWindowTitle("Maze Example"); // Set the app name on the title bar
	ofSetFrameRate(15);
	ofBackground(255, 255, 255);
	// Get the window size for image loading
	windowWidth = ofGetWidth();
	windowHeight = ofGetHeight();
	isdfs = false;
	//isBFS = false;
	isOpen = 0;
	// Centre on the screen
	ofSetWindowPosition((ofGetScreenWidth() - windowWidth) / 2, (ofGetScreenHeight() - windowHeight) / 2);

	// Load a font rather than the default
	myFont.loadFont("verdana.ttf", 12, true, true);

	// Load an image for the example
	//myImage.loadImage("lighthouse.jpg");

	// Window handle used for topmost function
	hWnd = WindowFromDC(wglGetCurrentDC());

	// Disable escape key exit so we can exit fullscreen with Escape (see keyPressed)
	ofSetEscapeQuitsApp(false);

	//
	// Create a menu using ofxWinMenu
	//

	// A new menu object with a pointer to this class
	menu = new ofxWinMenu(this, hWnd);

	// Register an ofApp function that is called when a menu item is selected.
	// The function can be called anything but must exist. 
	// See the example "appMenuFunction".
	menu->CreateMenuFunction(&ofApp::appMenuFunction);

	// Create a window menu
	HMENU hMenu = menu->CreateWindowMenu();

	//
	// Create a "File" popup menu
	//
	HMENU hPopup = menu->AddPopupMenu(hMenu, "File");

	//
	// Add popup items to the File menu
	//

	// Open an maze file
	menu->AddPopupItem(hPopup, "Open", false, false); // Not checked and not auto-checked

	// Final File popup menu item is "Exit" - add a separator before it
	menu->AddPopupSeparator(hPopup);
	menu->AddPopupItem(hPopup, "Exit", false, false);

	//
	// View popup menu
	//
	hPopup = menu->AddPopupMenu(hMenu, "View");

	bShowInfo = true;  // screen info display on
	menu->AddPopupItem(hPopup, "Show DFS", false, false); // Checked
	bTopmost = false; // app is topmost
	menu->AddPopupItem(hPopup, "Show BFS"); // Not checked (default)
	bFullscreen = false; // not fullscreen yet
	menu->AddPopupItem(hPopup, "Full screen", false, false); // Not checked and not auto-check

	//
	// Help popup menu
	//
	hPopup = menu->AddPopupMenu(hMenu, "Help");
	menu->AddPopupItem(hPopup, "About", false, false); // No auto check

	// Set the menu to the window
	menu->SetWindowMenu();

} // end Setup


//
// Menu function
//
// This function is called by ofxWinMenu when an item is selected.
// The the title and state can be checked for required action.
// 
void ofApp::appMenuFunction(string title, bool bChecked) {

	ofFileDialogResult result;
	string filePath;
	size_t pos;

	//
	// File menu
	//
	if (title == "Open") {
		freeMemory();
		readFile();
	}
	if (title == "Exit") {
		ofExit(); // Quit the application
		freeMemory();
	}

	//
	// Window menu
	//
	if (title == "Show DFS") {
		
		//bShowInfo = bChecked;  // Flag is used elsewhere in Draw()
		if (isOpen)
		{
			if (isBFS)
				isBFS = 0;
			for (int i = 0; i < HEIGHT * WIDTH; i++)
			{
				maze[i].k = 0;
			}
			DFS();
			
			bShowInfo = bChecked;
		}
		else
			cout << "you must open file first" << endl;

	}

	if (title == "Show BFS") {
		doTopmost(bChecked); // Use the checked value directly
		if (isOpen) 
		{
			if (isdfs) isdfs = 0;
			for (int i = 0; i < HEIGHT * WIDTH; i++)
			{
				maze[i].k = 0;
			}
			BFS();
			
			//bShowInfo = bChecked;
		}
		else
			cout << "you must open file first" << endl;
		

	}

	if (title == "Full screen") {
		bFullscreen = !bFullscreen; // Not auto-checked and also used in the keyPressed function
		doFullScreen(bFullscreen); // But als take action immediately
	}

	//
	// Help menu
	//
	if (title == "About") {
		ofSystemAlertDialog("ofxWinMenu\nbasic example\n\nhttp://spout.zeal.co");
	}

} // end appMenuFunction


//--------------------------------------------------------------
void ofApp::update() {

}


//--------------------------------------------------------------
void ofApp::draw() {

	char str[256];
	//ofBackground(0, 0, 0, 0);
	ofSetColor(100);
	ofSetLineWidth(5);
	int i = 0, j = 0, cnt = 0;

	// TO DO : DRAW MAZE; 
	// ����� �ڷᱸ���� �̿��� �̷θ� �׸���.
	// add code here


	if (isdfs)
	{
		if (isOpen)	dfsdraw();
		else
			cout << "You must open file first" << endl;
	}
	if (isBFS)
	{
		//if (isdfs) isdfs = false;
		if (isOpen) bfsdraw();
		else
			cout << "You must open file first" << endl;
	}
	if (isOpen)
	{
		ofSetColor(100);
		ofSetLineWidth(5);
		ofRectangle ra(0, 0, 22 * WIDTH + 2, 2);
		ofDrawRectangle(ra);
		for (i = 0; i < HEIGHT; i++)
		{
			ofRectangle rb(0, (22 * i), 2, 22);
			ofDrawRectangle(rb);
			for (j = 0; j < WIDTH; j++)
			{
				if (maze[cnt].right)
				{
					ofRectangle rc((j + 1) * 22, 22 * i, 2, 22);
					ofDrawRectangle(rc);
				}
				cnt++;

			}
			cnt = cnt - WIDTH;
			ofRectangle rd(0, i * 22, 2, 22);
			ofDrawRectangle(rd);
			for (j = 0; j < WIDTH; j++) {
				if (maze[cnt].down)
				{
					ofRectangle re(j * 22 + 2, (i + 1) * 22, 22, 2);
					ofDrawRectangle(re);
				}
				ofRectangle rf((j + 1) * 22, (i + 1) * 22, 2, 2);
				ofDrawRectangle(rf);
				cnt++;
			}
			ofRectangle rg(0, HEIGHT * 22, 2, 2);
			ofDrawRectangle(rg);
		}
	}


	
	if (bShowInfo) {
		// Show keyboard duplicates of menu functions
		sprintf(str, " comsil project");
		myFont.drawString(str, 15, ofGetHeight() - 20);
	}

} // end Draw


void ofApp::doFullScreen(bool bFull)
{
	// Enter full screen
	if (bFull) {
		// Remove the menu but don't destroy it
		menu->RemoveWindowMenu();
		// hide the cursor
		ofHideCursor();
		// Set full screen
		ofSetFullscreen(true);
	}
	else {
		// return from full screen
		ofSetFullscreen(false);
		// Restore the menu
		menu->SetWindowMenu();
		// Restore the window size allowing for the menu
		ofSetWindowShape(windowWidth, windowHeight + GetSystemMetrics(SM_CYMENU));
		// Centre on the screen
		ofSetWindowPosition((ofGetScreenWidth() - ofGetWidth()) / 2, (ofGetScreenHeight() - ofGetHeight()) / 2);
		// Show the cursor again
		ofShowCursor();
		// Restore topmost state
		if (bTopmost) doTopmost(true);
	}

} // end doFullScreen


void ofApp::doTopmost(bool bTop)
{
	if (bTop) {
		// get the current top window for return
		hWndForeground = GetForegroundWindow();
		// Set this window topmost
		SetWindowPos(hWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
		ShowWindow(hWnd, SW_SHOW);
	}
	else {
		SetWindowPos(hWnd, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
		ShowWindow(hWnd, SW_SHOW);
		// Reset the window that was topmost before
		if (GetWindowLong(hWndForeground, GWL_EXSTYLE) & WS_EX_TOPMOST)
			SetWindowPos(hWndForeground, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
		else
			SetWindowPos(hWndForeground, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
	}
} // end doTopmost


//--------------------------------------------------------------
void ofApp::keyPressed(int key) {

	// Escape key exit has been disabled but it can be checked here
	if (key == VK_ESCAPE) {
		// Disable fullscreen set, otherwise quit the application as usual
		if (bFullscreen) {
			bFullscreen = false;
			doFullScreen(false);
		}
		else {
			ofExit();
		}
	}

	// Remove or show screen info
	if (key == ' ') {
		bShowInfo = !bShowInfo;
		// Update the menu check mark because the item state has been changed here
		menu->SetPopupItem("Show DFS", bShowInfo);
	}

	if (key == 'f') {
		bFullscreen = !bFullscreen;
		doFullScreen(bFullscreen);
		// Do not check this menu item
		// If there is no menu when you call the SetPopupItem function it will crash
	}

} // end keyPressed

//--------------------------------------------------------------
void ofApp::keyReleased(int key) {

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y) {

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button) {

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button) {

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button) {

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h) {

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg) {

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo) {

}
bool ofApp::readFile()
{
	ofFileDialogResult openFileResult = ofSystemLoadDialog("Select .maz file");
	string filePath;
	size_t pos;
	// Check whether the user opened a file
	if (openFileResult.bSuccess) {
		ofLogVerbose("User selected a file");

		//We have a file, check it and process it
		string fileName = openFileResult.getName();
		//string fileName = "maze0.maz";
		cout << "file name is " << fileName << endl;
		filePath = openFileResult.getPath();
		printf("Open\n");
		pos = filePath.find_last_of(".");
		if (pos != string::npos && pos != 0 && filePath.substr(pos + 1) == "maz") {

			ofFile file(fileName);

			if (!file.exists()) {
				cout << "Target file does not exists." << endl;
				return false;
			}
			else {
				cout << "We found the target file." << endl;
				isOpen = 1;
			}

			ofBuffer buffer(file);

			// Input_flag is a variable for indication the type of input.
			// If input_flag is zero, then work of line input is progress.
			// If input_flag is one, then work of dot input is progress.
			int input_flag = 0;

			// Idx is a variable for index of array.
			int idx = 0;

			// Read file line by line
			int cnt = 0;

			int i = 0, j = 0;

			HEIGHT = 0; WIDTH = 0;
			string str = buffer.getText();
			while (str[idx] != 0)
			{
				if (cnt == 0 && str[idx] == '-') WIDTH++; // ù �࿡�� ���� ������ �ľ�
				if (str[idx] == '\n') cnt++; //�������� ���� ������ �ľ�
				idx++;
			}
			HEIGHT = cnt / 2; //.maz ������ ���� ��Ÿ���� ���� �����Ƿ� ������ 2
			maze = (Maze*)malloc(sizeof(Maze) * (HEIGHT+1) * (WIDTH+1));
			cnt = 0; idx = 0;
			while (str[idx] != 0)
			{
				if (str[idx] == '\r') 
				{
					idx++;
					continue;
				}
				if (str[idx] == '\n')
				{
					j = 0; i += 1; idx++; continue;
				} //����
				if (i % 2 && j % 2)
				{
					maze[cnt].room = cnt;
					maze[cnt].down = 0;
					maze[cnt].up = 0;
					maze[cnt].right = 0;
					maze[cnt].left = 0;
					maze[cnt].k = 0;
					if (str[idx - 1] == '|') maze[cnt].left = 1;
					if (str[idx + 1] == '|') maze[cnt].right = 1;
					if (str[idx + 2 * WIDTH + 3] == '-') maze[cnt].down = 1;
					if (str[idx - 2 * WIDTH - 3] == '-') maze[cnt].up = 1;
					cnt++;
				}
				j++; idx++;
			}
			// TO DO
			// .maz ������ input���� �޾Ƽ� ������ �ڷᱸ���� �ִ´�
			return true;
		}
		else {
			printf("  Needs a '.maz' extension\n");
			return false;
		}
	}
}
void ofApp::freeMemory() {
	dfsway.clear();
	stack.clear();
	free(maze);
	for (int i = 0; i < HEIGHT; i++)
	{
		free(bfsway[i]);
	}
	free(bfsway);
	isdfs = 0;
	isBFS = 0;
	//TO DO
	// malloc�� memory�� free���ִ� �Լ�
}

bool ofApp::DFS()//DFSŽ���� �ϴ� �Լ�
{
	int cur=0;
	maze[cur].k = 1;
	stack.push_back(maze[cur]);
	dfsway.push_back(maze[cur]);
	while (cur != HEIGHT * WIDTH - 1)
	{
		if (maze[cur].right == 0 && maze[cur + 1].k == 0)
		{
			//printf("right\n");
			cur++;
			maze[cur].k = 1;
			stack.push_back(maze[cur]);
			dfsway.push_back(maze[cur]);
		}
		else if (maze[cur].down == 0 && maze[cur + WIDTH].k == 0)
		{
			//printf("down\n");
			cur += WIDTH;
			maze[cur].k = 1;
			stack.push_back(maze[cur]);
			dfsway.push_back(maze[cur]);
		}
		else if (maze[cur].left == 0 && maze[cur - 1].k == 0)
		{
			//printf("left\n");
			cur--;
			maze[cur].k = 1;
			stack.push_back(maze[cur]);
			dfsway.push_back(maze[cur]);
		}
		else if (maze[cur].up == 0 && maze[cur - WIDTH].k == 0)
		{
			//printf("up\n");
			cur -= WIDTH;
			maze[cur].k = 1;
			stack.push_back(maze[cur]);
			dfsway.push_back(maze[cur]);
		}
		
		else
		{
			//printf("pop\n");
			stack.pop_back();
			cur = stack.back().room;
			dfsway.push_back(maze[cur]);
		}
	}
	isdfs = true;
	//TO DO
	//DFSŽ���� �ϴ� �Լ� ( 3����)
	return false;
}

bool ofApp::BFS()
{
	int i, j;
	int cur = 0;
	maze[0].k = 1;
	queue.push(maze[0]);
	bfsway = (int**)calloc(HEIGHT, sizeof(int*));
	for (i = 0; i < HEIGHT; i++)
	{
		bfsway[i] = (int*)calloc(WIDTH, sizeof(int));
		for (j = 0; j < WIDTH; j++)
		{
			bfsway[i][j] = 987654321;
		}
	}
	while (!queue.empty())
	{
		Maze temp;
		temp = queue.front();
		queue.pop();
		if (temp.room == HEIGHT * WIDTH - 1) break;
		maze[temp.room].k = 1;
		i = temp.room / WIDTH;
		j = temp.room % WIDTH;
		if (temp.right == 0 && maze[i * WIDTH + j + 1].k == 0)
		{
			maze[i * WIDTH + j + 1].k = 1;
			maze[i * WIDTH + j + 1].way = temp.room;
			bfsway[i][j + 1] = bfsway[i][j] + 1;
			queue.push(maze[i * WIDTH + j + 1]);
		}
		if (temp.down == 0 && maze[(i + 1) * WIDTH + j].k == 0)
		{
			maze[(i + 1) * WIDTH + j].k = 1;
			maze[(i + 1) * WIDTH + j].way = temp.room;
			bfsway[i + 1][j] = bfsway[i][j] + 1;
			queue.push(maze[(i + 1) * WIDTH + j]);
		}
		if (temp.left == 0 && maze[i * WIDTH + j - 1].k == 0)
		{
			maze[i * WIDTH + j - 1].k = 1;
			maze[i * WIDTH + j - 1].way = temp.room;
			bfsway[i][j - 1] = bfsway[i][j] + 1;
			queue.push(maze[i * WIDTH + j - 1]);
		}
		if (temp.up == 0 && maze[(i - 1) * WIDTH + j].k == 0)
		{
			maze[(i - 1) * WIDTH + j].k = 1;
			maze[(i - 1) * WIDTH + j].way = temp.room;
			bfsway[i - 1][j] = bfsway[i][j] + 1;
			queue.push(maze[(i - 1) * WIDTH + j]);
		}
	}
	isBFS = true;
	return false;
}

void ofApp::dfsdraw()
{
	int i, j, cnt;
	int x, y, deltax, deltay;
	ofSetColor(0, 255, 0);
	for (cnt = 0; cnt < dfsway.size(); cnt++)
	{
		i = (dfsway[cnt].room / WIDTH);
		j = (dfsway[cnt].room % WIDTH);
		ofRectangle ra(j * 22 + 10, i * 22 + 10, 4, 4);
		ofDrawRectangle(ra);
		if (cnt) 
		{
			y = (dfsway[cnt - 1].room / WIDTH);
			x = (dfsway[cnt - 1].room % WIDTH);
			deltay = i - y;
			deltax = j - x;
			if ((abs(deltay) == 1) ^ (abs(deltax) == 1)) 
			{
				ofRectangle rb((x<j ? x:j) * 22 + 10, (y<i ? y:i) * 22 + 10, abs(deltax) * 22 + (!abs(deltax)) * 4, abs(deltay) * 22 + (!abs(deltay)) * 4);
				ofDrawRectangle(rb);
			}
		}

	}
	ofSetColor(255, 0, 0);
	for (cnt = 0; cnt < stack.size(); cnt++) {
		i = (stack[cnt].room / WIDTH);
		j = (stack[cnt].room % WIDTH);
		ofRectangle ra(j * 22 + 10, i * 22 + 10, 4, 4);
		ofDrawRectangle(ra);
		if (cnt) 
		{
			y = (stack[cnt - 1].room / WIDTH);
			x = (stack[cnt - 1].room % WIDTH);
			ofRectangle rb((x<j ? x:j) * 22 + 10, (y<i ? y:i) * 22 + 10, abs(j - x) * 22 + (!abs(j - x)) * 4, abs(i - y) * 22 + (!abs(i - y)) * 4);
			ofDrawRectangle(rb);
		}

	}
	//TO DO 
	//DFS�� ������ ����� �׸���. (3���� ����)
}


void ofApp::bfsdraw()
{
	int i, j, k, cur;
	int x, y, flag=0;
	int delta[4][2] = { {0, 1}, {1, 0}, {0, -1}, {-1, 0} };
	ofSetColor(0, 255, 0);
	for (i = 0; i < HEIGHT; i++)
	{
		for (j = 0; j < WIDTH; j++)
		{
			if (bfsway[i][j] <= WIDTH * HEIGHT)
			{
				ofRectangle ra(j * 22 + 10, i * 22 + 10, 4, 4);
				ofDrawRectangle(ra);
			}
			for (k = 0; k < 4; k++)
			{
				flag = 0;
				y = i + delta[k][0];
				x = j + delta[k][1];
				if (x >= 0 && x < WIDTH && y >= 0 && y < HEIGHT)
				{
					if (bfsway[y][x] == bfsway[i][j] + 1)
					{
						switch (k)
						{
							case 0:
								if (!maze[i * WIDTH + j].right) flag = 1;
								break;
							case 1:
								if (!maze[i * WIDTH + j].down) flag = 1;
								break;
							case 2:
								if (!maze[i * WIDTH + j].left) flag = 1;
								break;
							case 3:
								if (!maze[i * WIDTH + j].up) flag = 1;
								break;
						}
						if (flag)
						{
							ofRectangle rb((x < j ? x : j) * 22 + 10, (y < i ? y : i) * 22 + 10, abs(delta[k][1]) * 22 + (!abs(delta[k][1])) * 4, abs(delta[k][0]) * 22 + (!abs(delta[k][0])) * 4);
							ofDrawRectangle(rb);
						}
					}
				}
			}
		}
	}
	ofSetColor(255, 0, 0);
	cur = HEIGHT * WIDTH - 1;
	while (cur != 0)
	{
		i = maze[cur].room / WIDTH;
		j = maze[cur].room % WIDTH;
		ofRectangle ra(j * 22 + 10, i * 22 + 10, 4, 4);
		ofDrawRectangle(ra);
		cur = maze[cur].way;
		y = maze[cur].room / WIDTH;
		x = maze[cur].room % WIDTH;
		ofRectangle rb((x < j ? x : j) * 22 + 10, (y < i ? y : i) * 22 + 10, abs(x - j) * 22 + (!abs(x - j)) * 4, abs(y - i) * 22 + (!abs(y - i)) * 4);
		ofDrawRectangle(rb);
	}
}